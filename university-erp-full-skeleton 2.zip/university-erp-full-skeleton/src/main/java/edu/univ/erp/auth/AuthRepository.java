package edu.univ.erp.auth;

import edu.univ.erp.domain.UserAccount;
import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AuthRepository {

    public UserAccount findByUsername(String username) {
        if (username == null || username.isBlank()) {
            return null;
        }

        final String sql = "SELECT user_id, username, role, status FROM users_auth WHERE username = ?";

        try (Connection conn = DbConnectionPool.authDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    UserAccount ua = new UserAccount();
                    ua.setUserId(rs.getLong("user_id"));
                    ua.setUsername(rs.getString("username"));
                    ua.setRole(rs.getString("role"));
                    ua.setStatus(rs.getString("status"));
                    return ua;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch user by username: " + username, e);
        }

        return null;
    }

    public String getPasswordHash(String username) {
        if (username == null || username.isBlank()) {
            return null;
        }

        final String sql = "SELECT password_hash FROM users_auth WHERE username = ?";

        try (Connection conn = DbConnectionPool.authDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("password_hash");
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch password hash for username: " + username, e);
        }

        return null;
    }

    public void insertUser(long userId, String username, String role, String hash, String status) {
        final String sql = "INSERT INTO users_auth (user_id, username, role, password_hash, status) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DbConnectionPool.authDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, userId);
            ps.setString(2, username);
            ps.setString(3, role);
            ps.setString(4, hash);
            ps.setString(5, status);
            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to insert user: " + username, e);
        }
    }
}
