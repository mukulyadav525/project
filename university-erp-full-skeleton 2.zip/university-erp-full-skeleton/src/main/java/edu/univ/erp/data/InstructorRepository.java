package edu.univ.erp.data;

import edu.univ.erp.domain.Instructor;
import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class InstructorRepository {

    public Instructor findByUserId(long userId) {
        if (userId <= 0) {
            throw new IllegalArgumentException("User ID must be positive.");
        }

        final String sql = "SELECT instructor_id, user_id, department FROM instructors WHERE user_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Instructor instructor = new Instructor();
                    instructor.setInstructorId(rs.getLong("instructor_id"));
                    instructor.setUserId(rs.getLong("user_id"));
                    instructor.setDepartment(rs.getString("department"));
                    return instructor;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to find instructor by userId: " + userId, e);
        }

        return null;
    }
}
