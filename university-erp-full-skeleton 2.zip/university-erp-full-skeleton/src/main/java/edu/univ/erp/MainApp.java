package edu.univ.erp;

import edu.univ.erp.ui.auth.LoginFrame;

import javax.swing.*;

/**
 * Entry point for the University ERP desktop application.
 * Launches the Swing-based login window on the Event Dispatch Thread (EDT).
 */
public class MainApp {

    public static void main(String[] args) {
        // Ensure consistent system look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            LoginFrame frame = new LoginFrame();
            frame.setVisible(true);
        });
    }
}
