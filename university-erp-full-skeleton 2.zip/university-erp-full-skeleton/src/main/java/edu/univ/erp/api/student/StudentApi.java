package edu.univ.erp.api.student;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.service.StudentService;
import edu.univ.erp.data.SettingsRepository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class StudentApi {

    private final StudentService studentService = new StudentService();
    private final SettingsRepository settingsRepository = new SettingsRepository();

    public ApiResponse<Void> registerInSection(long sectionId) {
        if (sectionId <= 0) {
            return ApiResponse.fail("Invalid section ID.");
        }

        // Block if after registration deadline
        LocalDateTime regDeadline = settingsRepository.getRegistrationDeadline();
        if (regDeadline != null && LocalDateTime.now().isAfter(regDeadline)) {
            return ApiResponse.fail("Registration deadline has passed.");
        }

        String err = studentService.registerCurrentStudentInSection(sectionId);
        return (err == null) ? ApiResponse.ok(null) : ApiResponse.fail(err);
    }

    public ApiResponse<Void> dropSection(long sectionId) {
        if (sectionId <= 0) {
            return ApiResponse.fail("Invalid section ID.");
        }

        // Block if after drop deadline
        LocalDateTime dropDeadline = settingsRepository.getDropDeadline();
        if (dropDeadline != null && LocalDateTime.now().isAfter(dropDeadline)) {
            return ApiResponse.fail("Drop deadline has passed.");
        }

        String err = studentService.dropCurrentStudentFromSection(sectionId);
        return (err == null) ? ApiResponse.ok(null) : ApiResponse.fail(err);
    }


    public ApiResponse<List<Enrollment>> myEnrollments() {
        List<Enrollment> enrollments = studentService.getMyEnrollments();
        if (enrollments == null || enrollments.isEmpty()) {
            return ApiResponse.error("No enrollments found for the current student.");
        }
        return ApiResponse.ok(enrollments);
    }

    // -----------------------------------------------------------------------
    // NEW: provide registration deadline to StudentCatalogPanel
    // -----------------------------------------------------------------------
    public ApiResponse<String> getRegistrationDeadline() {
        try {
            LocalDateTime deadline = settingsRepository.getRegistrationDeadline();
            if (deadline == null) {
                return ApiResponse.ok(null); // no deadline configured
            }

            // Format for display (e.g. Nov 15, 2025 11:59 PM)
            String formatted = deadline.format(
                    DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a")
            );
            return ApiResponse.ok(formatted);

        } catch (Exception e) {
            return ApiResponse.fail("Failed to fetch registration deadline: " + e.getMessage());
        }
    }

    public ApiResponse<String> getDropDeadline() {
        try {
            // assumes you have this in SettingsRepository
            LocalDateTime deadline = settingsRepository.getDropDeadline();
            if (deadline == null) {
                return ApiResponse.ok(null); // no deadline configured
            }

            String formatted = deadline.format(
                    DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a")
            );
            return ApiResponse.ok(formatted);

        } catch (Exception e) {
            return ApiResponse.fail("Failed to fetch drop deadline: " + e.getMessage());
        }
    }
}
