package edu.univ.erp.domain;

public class Student {

    private long studentId;
    private long userId;
    private String rollNo;
    private String program;
    private int year;

    public Student() {
    }

    public Student(long studentId, long userId, String rollNo, String program, int year) {
        this.studentId = studentId;
        this.userId = userId;
        this.rollNo = rollNo;
        this.program = program;
        this.year = year;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 0) {
            throw new IllegalArgumentException("Year cannot be negative.");
        }
        this.year = year;
    }

    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", userId=" + userId +
                ", rollNo='" + rollNo + '\'' +
                ", program='" + program + '\'' +
                ", year=" + year +
                '}';
    }
}
