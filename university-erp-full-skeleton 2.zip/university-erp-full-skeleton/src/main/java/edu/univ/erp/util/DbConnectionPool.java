package edu.univ.erp.util;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import javax.sql.DataSource;

public class DbConnectionPool {

    private static final HikariDataSource AUTH_DS;
    private static final HikariDataSource ERP_DS;

    static {
        try {
            String driverClass = "com.mysql.cj.jdbc.Driver"; // MySQL Connector/J

            // ---------- AUTH DB ----------
            HikariConfig authCfg = new HikariConfig();
            authCfg.setDriverClassName(driverClass);
            authCfg.setJdbcUrl(DbConfig.get("auth.jdbc.url"));
            authCfg.setUsername(DbConfig.get("auth.db.user"));
            authCfg.setPassword(DbConfig.get("auth.db.pass"));
            authCfg.setMaximumPoolSize(5);
            authCfg.setMinimumIdle(1);
            authCfg.setPoolName("AuthPool");
            AUTH_DS = new HikariDataSource(authCfg);

            // ---------- ERP DB ----------
            HikariConfig erpCfg = new HikariConfig();
            erpCfg.setDriverClassName(driverClass);
            erpCfg.setJdbcUrl(DbConfig.get("erp.jdbc.url"));
            erpCfg.setUsername(DbConfig.get("erp.db.user"));
            erpCfg.setPassword(DbConfig.get("erp.db.pass"));
            erpCfg.setMaximumPoolSize(10);
            erpCfg.setMinimumIdle(1);
            erpCfg.setPoolName("ErpPool");
            ERP_DS = new HikariDataSource(erpCfg);

        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize database connection pools", e);
        }
    }

    public static DataSource authDataSource() {
        return AUTH_DS;
    }

    public static DataSource erpDataSource() {
        return ERP_DS;
    }
}
