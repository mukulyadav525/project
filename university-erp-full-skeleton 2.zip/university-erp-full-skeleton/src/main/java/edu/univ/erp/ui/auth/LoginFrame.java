package edu.univ.erp.ui.auth;

import edu.univ.erp.api.auth.AuthApi;
import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.domain.UserAccount;
import edu.univ.erp.ui.admin.AdminDashboard;
import edu.univ.erp.ui.instructor.InstructorDashboard;
import edu.univ.erp.ui.student.StudentDashboard;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {

    private final AuthApi authApi = new AuthApi();
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel messageLabel;

    public LoginFrame() {
        setTitle("IIITD University ERP - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 300);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        // Left panel with institute branding
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(new Color(0x123456));
        JLabel instituteLabel = new JLabel("<html><center><b>IIITD</b><br>University ERP System</center></html>");
        instituteLabel.setForeground(Color.WHITE);
        instituteLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        instituteLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel infoLabel = new JLabel("<html><center>Login as a <b>Student</b>, <b>Instructor</b>, or <b>Admin</b><br>" +
                "to access your respective dashboard and system features.</center></html>");
        infoLabel.setForeground(Color.LIGHT_GRAY);
        infoLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        infoLabel.setHorizontalAlignment(SwingConstants.CENTER);

        leftPanel.add(instituteLabel, BorderLayout.CENTER);
        leftPanel.add(infoLabel, BorderLayout.SOUTH);

        // Right panel for login form
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new GridBagLayout());
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");
        messageLabel = new JLabel(" ", SwingConstants.CENTER);

        loginButton.addActionListener(e -> doLogin());

        gbc.gridx = 0;
        gbc.gridy = 0;
        rightPanel.add(new JLabel("Username:"), gbc);
        gbc.gridy++;
        rightPanel.add(usernameField, gbc);
        gbc.gridy++;
        rightPanel.add(new JLabel("Password:"), gbc);
        gbc.gridy++;
        rightPanel.add(passwordField, gbc);
        gbc.gridy++;
        rightPanel.add(loginButton, gbc);
        gbc.gridy++;
        rightPanel.add(messageLabel, gbc);

        // Split layout
        setLayout(new GridLayout(1, 2));
        add(leftPanel);
        add(rightPanel);
    }

    private void doLogin() {
        String u = usernameField.getText().trim();
        String p = new String(passwordField.getPassword()).trim();

        if (u.isEmpty() || p.isEmpty()) {
            messageLabel.setText("Please enter both username and password.");
            return;
        }

        ApiResponse<UserAccount> resp = authApi.login(u, p);
        if (!resp.isSuccess()) {
            messageLabel.setText(resp.getMessage());
            return;
        }

        UserAccount user = resp.getData();
        messageLabel.setText("Welcome, " + user.getUsername() + "! Logging in as " + user.getRole() + "...");
        SwingUtilities.invokeLater(() -> openDashboard(user.getRole()));
    }

    private void openDashboard(String role) {
        dispose();
        switch (role.toUpperCase()) {
            case "STUDENT" -> new StudentDashboard().setVisible(true);
            case "INSTRUCTOR" -> new InstructorDashboard().setVisible(true);
            case "ADMIN" -> new AdminDashboard().setVisible(true);
            default -> {
                JOptionPane.showMessageDialog(this, "Unknown role: " + role);
                System.exit(1);
            }
        }
    }
}
