package edu.univ.erp.data;

import edu.univ.erp.domain.Student;
import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StudentRepository {

    public Student findByUserId(long userId) {
        if (userId <= 0) {
            throw new IllegalArgumentException("User ID must be positive.");
        }

        final String sql = "SELECT student_id, user_id, roll_no, program, year FROM students WHERE user_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, userId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Student student = new Student();
                    student.setStudentId(rs.getLong("student_id"));
                    student.setUserId(rs.getLong("user_id"));
                    student.setRollNo(rs.getString("roll_no"));
                    student.setProgram(rs.getString("program"));
                    student.setYear(rs.getInt("year"));
                    return student;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to find student by userId: " + userId, e);
        }

        return null;
    }
}
