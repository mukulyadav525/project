package edu.univ.erp.data;

import edu.univ.erp.domain.Grade;
import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class GradeRepository {

    public void upsertComponent(long enrollmentId, String component, double score) {
        if (enrollmentId <= 0) {
            throw new IllegalArgumentException("enrollmentId must be positive.");
        }
        if (component == null || component.isBlank()) {
            throw new IllegalArgumentException("component must not be empty.");
        }

        final String selectSql =
                "SELECT grade_id FROM grades WHERE enrollment_id = ? AND component = ?";
        final String insertSql =
                "INSERT INTO grades (enrollment_id, component, score) VALUES (?, ?, ?)";
        final String updateSql =
                "UPDATE grades SET score = ? WHERE grade_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection()) {
            long existingId = -1L;

            try (PreparedStatement ps = conn.prepareStatement(selectSql)) {
                ps.setLong(1, enrollmentId);
                ps.setString(2, component);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        existingId = rs.getLong("grade_id");
                    }
                }
            }

            if (existingId == -1L) {
                try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
                    ps.setLong(1, enrollmentId);
                    ps.setString(2, component);
                    ps.setDouble(3, score);
                    ps.executeUpdate();
                }
            } else {
                try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                    ps.setDouble(1, score);
                    ps.setLong(2, existingId);
                    ps.executeUpdate();
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to upsert grade component for enrollmentId=" +
                    enrollmentId + ", component=" + component, e);
        }
    }

    public List<Grade> findByEnrollment(long enrollmentId) {
        List<Grade> list = new ArrayList<>();
        if (enrollmentId <= 0) {
            return list;
        }

        final String sql =
                "SELECT grade_id, enrollment_id, component, score, final_grade " +
                        "FROM grades WHERE enrollment_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, enrollmentId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Grade g = new Grade();
                    g.setGradeId(rs.getLong("grade_id"));
                    g.setEnrollmentId(rs.getLong("enrollment_id"));
                    g.setComponent(rs.getString("component"));
                    g.setScore(rs.getDouble("score"));
                    g.setFinalGrade((Double) rs.getObject("final_grade"));
                    list.add(g);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch grades for enrollmentId=" + enrollmentId, e);
        }

        return list;
    }

    public void setFinalGrade(long enrollmentId, double finalGrade) {
        if (enrollmentId <= 0) {
            throw new IllegalArgumentException("enrollmentId must be positive.");
        }

        final String sql =
                "UPDATE grades SET final_grade = ? WHERE enrollment_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, finalGrade);
            ps.setLong(2, enrollmentId);
            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to set final grade for enrollmentId=" +
                    enrollmentId, e);
        }
    }
}
