package edu.univ.erp.service;

import edu.univ.erp.auth.SessionContext;
import edu.univ.erp.data.EnrollmentRepository;
import edu.univ.erp.data.SectionRepository;
import edu.univ.erp.data.SettingsRepository;   // 🔹 NEW: import added
import edu.univ.erp.data.StudentRepository;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.Student;
import edu.univ.erp.domain.UserAccount;

import java.time.LocalDateTime;                 // 🔹 NEW: import added
import java.util.List;

public class StudentService {

    private final StudentRepository studentRepository = new StudentRepository();
    private final SectionRepository sectionRepository = new SectionRepository();
    private final EnrollmentRepository enrollmentRepository = new EnrollmentRepository();
    private final MaintenanceService maintenanceService = new MaintenanceService();
    private final SettingsRepository settingsRepository = new SettingsRepository(); // 🔹 NEW

    /**
     * Resolve the currently logged-in student from the session.
     * Returns null if not logged in, not a STUDENT, or no student record found.
     */
    private Student currentStudentOrError() {
        UserAccount user = SessionContext.getCurrentUser();
        if (user == null || !"STUDENT".equalsIgnoreCase(user.getRole())) {
            return null;
        }
        return studentRepository.findByUserId(user.getUserId());
    }

    /**
     * Register the current student into the given section.
     *
     * @param sectionId target section ID
     * @return null on success, or an error message string on failure
     */
    public String registerCurrentStudentInSection(long sectionId) {
        if (sectionId <= 0) {
            return "Invalid section ID.";
        }

        Student student = currentStudentOrError();
        if (student == null) {
            return "Only logged-in students can register.";
        }

        if (maintenanceService.isMaintenanceOn()) {
            return "Registration is disabled: maintenance mode is ON.";
        }

        // 🔹 NEW: registration deadline enforcement
        LocalDateTime deadline = settingsRepository.getRegistrationDeadline();
        if (deadline != null && LocalDateTime.now().isAfter(deadline)) {
            return "Registration deadline (" + deadline + ") has passed. You can no longer register.";
        }

        Section section = sectionRepository.findById(sectionId);
        if (section == null) {
            return "Section not found.";
        }

        if (enrollmentRepository.exists(student.getStudentId(), sectionId)) {
            return "You are already registered in this section.";
        }

        int enrolled = enrollmentRepository.countBySection(sectionId);
        if (enrolled >= section.getCapacity()) {
            return "Section full.";
        }

        boolean ok = enrollmentRepository.insert(student.getStudentId(), sectionId);
        return ok ? null : "Failed to register. Please try again.";
    }

    /**
     * Drop the current student from the given section.
     *
     * @param sectionId target section ID
     * @return null on success, or an error message string on failure
     */
    public String dropCurrentStudentFromSection(long sectionId) {
        if (sectionId <= 0) {
            return "Invalid section ID.";
        }

        Student student = currentStudentOrError();
        if (student == null) {
            return "Only logged-in students can drop.";
        }

        if (maintenanceService.isMaintenanceOn()) {
            return "Drop is disabled: maintenance mode is ON.";
        }

        boolean ok = enrollmentRepository.delete(student.getStudentId(), sectionId);
        return ok ? null : "Not enrolled in this section or drop failed.";
    }

    /**
     * Get all enrollments for the current student.
     *
     * @return list of enrollments (empty if not logged in or no enrollments)
     */
    public List<Enrollment> getMyEnrollments() {
        Student student = currentStudentOrError();
        if (student == null) {
            return List.of();
        }
        return enrollmentRepository.findByStudent(student.getStudentId());
    }

    // Timetable view & grades can be derived from enrollments + sections + grades; add as needed.
}
