package edu.univ.erp.service;

import edu.univ.erp.data.SettingsRepository;

/**
 * Service layer for system maintenance mode.
 *
 * Delegates persistence to SettingsRepository.
 * Supports:
 *  - Enabling/disabling maintenance mode
 *  - Reading current maintenance state
 *  - Setting/retrieving a banner message
 */
public class MaintenanceService {

    private final SettingsRepository settingsRepository = new SettingsRepository();

    /**
     * Returns true if maintenance mode is ON.
     */
    public boolean isMaintenanceOn() {
        return settingsRepository.isMaintenanceOn();
    }

    /**
     * Sets maintenance mode ON or OFF.
     * Matches method name used in AdminService and other classes.
     */
    public void setMaintenanceOn(boolean on) {
        settingsRepository.setMaintenance(on);
    }

    /**
     * Toggles the current maintenance mode.
     */
    public void toggle() {
        setMaintenanceOn(!isMaintenanceOn());
    }

    // ==========================================================
    // Banner message support
    // ==========================================================

    /**
     * Set the maintenance banner message to be displayed in UI when ON.
     * Expected SettingsRepository method:
     *   void setMaintenanceBanner(String banner)
     */
    public void setMaintenanceBanner(String bannerMessage) {
        settingsRepository.setMaintenanceBanner(bannerMessage);
    }

    /**
     * Get the current maintenance banner message.
     * Expected SettingsRepository method:
     *   String getMaintenanceBanner()
     */
    public String getMaintenanceBanner() {
        return settingsRepository.getMaintenanceBanner();
    }
}
