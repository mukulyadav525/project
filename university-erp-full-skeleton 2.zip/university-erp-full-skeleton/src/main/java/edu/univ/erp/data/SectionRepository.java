package edu.univ.erp.data;

import edu.univ.erp.domain.Section;
import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class SectionRepository {

    private static final String BASE_SELECT =
            "SELECT " +
                    "s.section_id, " +
                    "s.course_code, " +
                    "s.instructor_id, " +
                    "ua.full_name AS instructor_name, " +   // uses user_accounts.full_name
                    "s.day_time, " +
                    "s.room, " +
                    "s.capacity, " +
                    "s.semester, " +
                    "s.year " +
                    "FROM sections s " +
                    "LEFT JOIN instructors i ON s.instructor_id = i.instructor_id " +
                    "LEFT JOIN user_accounts ua ON i.user_id = ua.user_id";

    public List<Section> findAll() {
        List<Section> list = new ArrayList<>();

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(BASE_SELECT);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(map(rs));
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch all sections", e);
        }

        return list;
    }

    public List<Section> findByInstructor(long instructorId) {
        if (instructorId <= 0) {
            throw new IllegalArgumentException("Instructor ID must be positive.");
        }

        List<Section> list = new ArrayList<>();
        final String sql = BASE_SELECT + " WHERE s.instructor_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, instructorId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch sections for instructorId=" + instructorId, e);
        }

        return list;
    }

    public Section findById(long sectionId) {
        if (sectionId <= 0) {
            throw new IllegalArgumentException("Section ID must be positive.");
        }

        final String sql = BASE_SELECT + " WHERE s.section_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, sectionId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch section with id=" + sectionId, e);
        }

        return null;
    }

    public void insert(Section s) {
        if (s == null) {
            throw new IllegalArgumentException("Section must not be null.");
        }
        if (s.getCourseCode() == null || s.getCourseCode().isBlank()) {
            throw new IllegalArgumentException("Course code is required.");
        }

        final String sql =
                "INSERT INTO sections " +
                        "(course_code, instructor_id, day_time, room, capacity, semester, year) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, s.getCourseCode());

            if (s.getInstructorId() != null) {
                ps.setLong(2, s.getInstructorId());
            } else {
                ps.setNull(2, Types.BIGINT);
            }

            ps.setString(3, s.getDayTime());
            ps.setString(4, s.getRoom());
            ps.setInt(5, s.getCapacity());
            ps.setString(6, s.getSemester());
            ps.setInt(7, s.getYear());

            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to insert section", e);
        }
    }

    public void assignInstructor(long sectionId, long instructorId) {
        if (sectionId <= 0 || instructorId <= 0) {
            throw new IllegalArgumentException("Section ID and Instructor ID must be positive.");
        }

        final String sql = "UPDATE sections SET instructor_id = ? WHERE section_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, instructorId);
            ps.setLong(2, sectionId);
            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to assign instructorId=" + instructorId +
                    " to sectionId=" + sectionId, e);
        }
    }

    private Section map(ResultSet rs) throws SQLException {
        Section s = new Section();
        s.setSectionId(rs.getLong("section_id"));
        s.setCourseCode(rs.getString("course_code"));
        s.setInstructorId((Long) rs.getObject("instructor_id"));
        s.setInstructorName(rs.getString("instructor_name")); // from ua.full_name
        s.setDayTime(rs.getString("day_time"));
        s.setRoom(rs.getString("room"));
        s.setCapacity(rs.getInt("capacity"));
        s.setSemester(rs.getString("semester"));
        s.setYear(rs.getInt("year"));
        return s;
    }
}
