package edu.univ.erp.auth;

import edu.univ.erp.domain.UserAccount;
import org.mindrot.jbcrypt.BCrypt;

public class AuthService {

    private final AuthRepository authRepository = new AuthRepository();

    public UserAccount login(String username, String password) {
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            return null;
        }

        String hash = authRepository.getPasswordHash(username);
        if (hash == null || !BCrypt.checkpw(password, hash)) {
            return null;
        }

        UserAccount user = authRepository.findByUsername(username);
        if (user != null) {
            SessionContext.setCurrentUser(user);
        }

        return user;
    }

    public void logout() {
        SessionContext.clear();
    }

    public String hashPassword(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new IllegalArgumentException("Password cannot be empty.");
        }
        return BCrypt.hashpw(raw, BCrypt.gensalt());
    }
}
