package edu.univ.erp.util;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Small helper to generate BCrypt hashes using the SAME library
 * the application uses (jBCrypt 0.4).
 *
 * Run this once to get hashes for your seed users.
 */
public class GenerateHash {

    public static void main(String[] args) {
    }

    private static void printHash(String raw) {
        String hash = BCrypt.hashpw(raw, BCrypt.gensalt());
        System.out.println(raw + " -> " + hash);
    }
}

