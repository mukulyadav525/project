package edu.univ.erp.data;

import edu.univ.erp.domain.Course;
import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CourseRepository {

    public List<Course> findAll() {
        List<Course> list = new ArrayList<>();
        final String sql = "SELECT code, title, credits FROM courses";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Course c = new Course();
                c.setCode(rs.getString("code"));
                c.setTitle(rs.getString("title"));
                c.setCredits(rs.getInt("credits"));
                list.add(c);
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch courses", e);
        }

        return list;
    }

    public void insert(Course c) {
        if (c == null || c.getCode() == null || c.getTitle() == null) {
            throw new IllegalArgumentException("Course, code, and title must not be null.");
        }

        final String sql = "INSERT INTO courses (code, title, credits) VALUES (?, ?, ?)";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, c.getCode());
            ps.setString(2, c.getTitle());
            ps.setInt(3, c.getCredits());
            ps.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException("Failed to insert course: " + c.getCode(), e);
        }
    }
}
