package edu.univ.erp.service;

import edu.univ.erp.data.SectionRepository;
import edu.univ.erp.domain.Section;

import java.util.List;

public class CatalogService {

    private final SectionRepository sectionRepository = new SectionRepository();

    /**
     * Retrieves all available course sections.
     *
     * @return a non-null list of sections (empty if none found)
     */
    public List<Section> listAllSections() {
        List<Section> sections = sectionRepository.findAll();
        return sections != null ? sections : List.of();
    }
}
