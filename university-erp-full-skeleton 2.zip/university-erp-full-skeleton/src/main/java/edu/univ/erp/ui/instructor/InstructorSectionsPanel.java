package edu.univ.erp.ui.instructor;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.api.instructor.InstructorApi;
import edu.univ.erp.domain.Section;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.List;

/**
 * Shows all sections assigned to the currently logged-in instructor.
 */
public class InstructorSectionsPanel extends JPanel {

    private final InstructorApi instructorApi = new InstructorApi();
    private final JTable table;
    private final DefaultTableModel model;
    private final JLabel summaryLabel;

    public InstructorSectionsPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        // Header (title + hint)
        JPanel header = new JPanel(new BorderLayout());
        JLabel title = new JLabel("My Sections");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        header.add(title, BorderLayout.NORTH);

        JLabel hint = new JLabel(
                "<html>These are the sections assigned to your account for the current term.</html>"
        );
        hint.setFont(hint.getFont().deriveFont(Font.PLAIN, 11f));
        header.add(hint, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);

        // Table model
        model = new DefaultTableModel(
                new Object[]{"Section ID", "Course Code", "Day / Time", "Room"},
                0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Enable sorting on all columns
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        // Slightly nicer column sizing
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.getColumnModel().getColumn(0).setPreferredWidth(90);  // Section ID
        table.getColumnModel().getColumn(1).setPreferredWidth(110); // Course Code
        table.getColumnModel().getColumn(2).setPreferredWidth(180); // Day/Time
        table.getColumnModel().getColumn(3).setPreferredWidth(80);  // Room

        // On double-click: show basic detail popup for that section.
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2 && table.getSelectedRow() != -1) {
                    showSelectedSectionDetails();
                }
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);

        // Footer: summary + buttons
        JPanel footer = new JPanel(new BorderLayout(5, 5));

        summaryLabel = new JLabel(" ");
        summaryLabel.setFont(summaryLabel.getFont().deriveFont(Font.PLAIN, 11f));
        footer.add(summaryLabel, BorderLayout.WEST);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        JButton viewDetailsButton = new JButton("View Details");
        JButton refreshButton = new JButton("Refresh");

        viewDetailsButton.addActionListener(e -> showSelectedSectionDetails());
        refreshButton.addActionListener(e -> load());

        buttons.add(viewDetailsButton);
        buttons.add(refreshButton);
        footer.add(buttons, BorderLayout.EAST);

        add(footer, BorderLayout.SOUTH);

        load();
    }

    private void load() {
        model.setRowCount(0);
        summaryLabel.setText("Loading sections...");

        ApiResponse<List<Section>> resp = instructorApi.mySections();

        if (!resp.isSuccess()) {
            summaryLabel.setText(" ");
            if (resp.getMessage() != null && !resp.getMessage().isBlank()) {
                JOptionPane.showMessageDialog(
                        this,
                        resp.getMessage(),
                        "Error Loading Sections",
                        JOptionPane.ERROR_MESSAGE
                );
            }
            return;
        }

        List<Section> sections = resp.getData();
        if (sections == null || sections.isEmpty()) {
            summaryLabel.setText("No sections assigned to you for the current term.");
            return;
        }

        for (Section s : sections) {
            model.addRow(new Object[]{
                    s.getSectionId(),
                    s.getCourseCode(),
                    s.getDayTime(),
                    s.getRoom()
            });
        }

        summaryLabel.setText(sections.size() + " section(s) assigned to you.");
    }

    /**
     * Pops up details for the currently selected section.
     * Uses only safe, existing columns; will gracefully no-op if nothing is selected.
     */
    private void showSelectedSectionDetails() {
        int viewRow = table.getSelectedRow();
        if (viewRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a section first.",
                    "No Selection",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        int modelRow = table.convertRowIndexToModel(viewRow);

        String sectionId = String.valueOf(model.getValueAt(modelRow, 0));
        String courseCode = String.valueOf(model.getValueAt(modelRow, 1));
        String dayTime = String.valueOf(model.getValueAt(modelRow, 2));
        String room = String.valueOf(model.getValueAt(modelRow, 3));

        String message = "Section ID: " + sectionId +
                "\nCourse Code: " + courseCode +
                "\nDay / Time: " + dayTime +
                "\nRoom: " + room;

        JOptionPane.showMessageDialog(
                this,
                message,
                "Section Details",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
