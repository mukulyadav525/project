package edu.univ.erp.ui.student;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.api.student.StudentApi;
import edu.univ.erp.domain.Enrollment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Shows the current student's registrations and allows dropping sections.
 */
public class StudentRegistrationsPanel extends JPanel {

    private final StudentApi studentApi = new StudentApi();
    private final JTable table;
    private final DefaultTableModel model;

    public StudentRegistrationsPanel() {
        setLayout(new BorderLayout(5, 5));

        // ===== Header with deadlines =====
        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));

        JLabel title = new JLabel("My Course Registrations", SwingConstants.LEFT);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));

        JLabel deadlines = new JLabel(
                "Registration deadline: " + getRegistrationDeadlineText()
                        + "    |    Drop deadline: " + getDropDeadlineText(),
                SwingConstants.LEFT
        );
        deadlines.setFont(deadlines.getFont().deriveFont(Font.PLAIN, 12f));
        deadlines.setForeground(Color.DARK_GRAY);

        header.add(title);
        header.add(deadlines);

        add(header, BorderLayout.NORTH);

        // ===== Table =====
        model = new DefaultTableModel(
                new Object[]{"Enrollment ID", "Section ID", "Status"},
                0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFillsViewportHeight(true);

        add(new JScrollPane(table), BorderLayout.CENTER);

        // ===== Buttons =====
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        JButton refreshButton = new JButton("Refresh");
        JButton dropButton = new JButton("Drop Selected");

        refreshButton.addActionListener(e -> load());
        dropButton.addActionListener(e -> dropSelected());

        buttonPanel.add(refreshButton);
        buttonPanel.add(dropButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Initial load
        load();
    }

    private void load() {
        model.setRowCount(0);

        ApiResponse<List<Enrollment>> resp = studentApi.myEnrollments();
        if (!resp.isSuccess()) {
            if (resp.getMessage() != null && !resp.getMessage().isBlank()) {
                JOptionPane.showMessageDialog(
                        this,
                        resp.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
            return;
        }

        List<Enrollment> enrollments = resp.getData();
        if (enrollments == null || enrollments.isEmpty()) {
            // No enrollments; leave table empty
            return;
        }

        for (Enrollment e : enrollments) {
            model.addRow(new Object[]{
                    e.getEnrollmentId(),
                    e.getSectionId(),
                    e.getStatus()
            });
        }
    }

    private void dropSelected() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a registration to drop.",
                    "Selection Required",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Object sectionIdValue = model.getValueAt(row, 1);
        long sectionId;
        if (sectionIdValue instanceof Number n) {
            sectionId = n.longValue();
        } else {
            try {
                sectionId = Long.parseLong(sectionIdValue.toString());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid section ID format.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }
        }

        ApiResponse<Void> resp = studentApi.dropSection(sectionId);

        JOptionPane.showMessageDialog(
                this,
                resp.isSuccess() ? "Dropped successfully." : resp.getMessage(),
                resp.isSuccess() ? "Success" : "Error",
                resp.isSuccess() ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
        );

        if (resp.isSuccess()) {
            load();
        }
    }

    // ===== Helpers to read deadlines from StudentApi =====

    private String getRegistrationDeadlineText() {
        ApiResponse<String> resp = studentApi.getRegistrationDeadline();
        if (resp == null || !resp.isSuccess() || resp.getData() == null) {
            return "Not configured";
        }
        return resp.getData();
    }

    private String getDropDeadlineText() {
        ApiResponse<String> resp = studentApi.getDropDeadline();
        if (resp == null || !resp.isSuccess() || resp.getData() == null) {
            return "Not configured";
        }
        return resp.getData();
    }
}
