package edu.univ.erp.ui.admin;

import edu.univ.erp.ui.common.BaseFrame;

import javax.swing.*;

public class AdminDashboard extends BaseFrame {

    public AdminDashboard() {
        super("Admin Dashboard");

        JTabbedPane tabs = new JTabbedPane();

        // 1. Add users (students/instructors/admins)
        tabs.addTab("Users", new AdminUsersPanel()); // implement add/edit users here

        // 2. Create/edit courses
        tabs.addTab("Courses", new AdminCoursesPanel()); // create/edit course master data

        // 3. Create/edit sections
        tabs.addTab("Sections", new AdminSectionsPanel()); // day/time/room/capacity/semester/year

        // 4. Assign instructor to a section
        tabs.addTab("Assign Instructor to Section", new AdminAssignInstructorPanel());

        // 5. Toggle Maintenance Mode (ON/OFF) and display a banner
        tabs.addTab("Maintenance Mode", new AdminMaintenancePanel());

        setContentPane(tabs);
    }
}
