package edu.univ.erp.ui.student;

import edu.univ.erp.api.catalog.CatalogApi;
import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.api.student.StudentApi;
import edu.univ.erp.domain.Section;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Student view of the course catalog.
 * - Lists all available sections
 * - Allows registering in a selected section
 * - Shows registration deadline from backend
 */
public class StudentCatalogPanel extends JPanel {

    private final CatalogApi catalogApi = new CatalogApi();
    private final StudentApi studentApi = new StudentApi();

    private final JTable table;
    private final DefaultTableModel model;
    private final JLabel deadlineLabel;

    public StudentCatalogPanel() {
        setLayout(new BorderLayout(5, 5));

        // --- Top: title (left) + registration deadline (right) ---
        JLabel titleLabel = new JLabel("Course Catalog / Register for Sections", SwingConstants.LEFT);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 16f));

        deadlineLabel = new JLabel();
        deadlineLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        deadlineLabel.setFont(deadlineLabel.getFont().deriveFont(Font.PLAIN, 12f));
        deadlineLabel.setForeground(Color.DARK_GRAY);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));
        topPanel.add(titleLabel, BorderLayout.WEST);
        topPanel.add(deadlineLabel, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // --- Table: list sections (including Instructor column) ---
        model = new DefaultTableModel(
                new Object[]{"Section ID", "Course Code", "Day/Time", "Room", "Instructor", "Capacity"},
                0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        table = new JTable(model);
        table.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // --- Buttons: Refresh + Register ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        JButton refreshButton = new JButton("Refresh");
        JButton registerButton = new JButton("Register");

        refreshButton.addActionListener(e -> {
            loadSections();
            loadDeadline();
        });

        registerButton.addActionListener(e -> registerSelected());

        buttonPanel.add(refreshButton);
        buttonPanel.add(registerButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Initial load
        loadSections();
        loadDeadline();
    }

    /**
     * Load available sections into the table.
     */
    private void loadSections() {
        model.setRowCount(0);

        ApiResponse<List<Section>> resp = catalogApi.listSections();
        if (!resp.isSuccess()) {
            if (resp.getMessage() != null && !resp.getMessage().isBlank()) {
                JOptionPane.showMessageDialog(
                        this,
                        resp.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
            return;
        }

        List<Section> sections = resp.getData();
        if (sections == null || sections.isEmpty()) {
            return;
        }

        for (Section s : sections) {
            model.addRow(new Object[]{
                    s.getSectionId(),
                    s.getCourseCode(),
                    s.getDayTime(),
                    s.getRoom(),
                    s.getInstructorName(), // from JOIN in SectionRepository
                    s.getCapacity()
            });
        }
    }

    /**
     * Load and display the registration deadline from backend.
     */
    private void loadDeadline() {
        ApiResponse<String> resp = studentApi.getRegistrationDeadline();
        if (resp != null && resp.isSuccess()
                && resp.getData() != null && !resp.getData().isBlank()) {
            deadlineLabel.setText("Registration deadline: " + resp.getData());
        } else {
            deadlineLabel.setText("");
        }
    }

    /**
     * Register the currently selected section.
     */
    private void registerSelected() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a section to register.",
                    "Selection Required",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Object idValue = model.getValueAt(row, 0);
        long sectionId;
        if (idValue instanceof Number n) {
            sectionId = n.longValue();
        } else {
            try {
                sectionId = Long.parseLong(idValue.toString());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid section ID format.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }
        }

        ApiResponse<Void> resp = studentApi.registerInSection(sectionId);

        JOptionPane.showMessageDialog(
                this,
                resp.isSuccess() ? "Registered successfully!" : resp.getMessage(),
                resp.isSuccess() ? "Success" : "Error",
                resp.isSuccess() ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
        );

        if (resp.isSuccess()) {
            // Optional: reload sections if capacity/status may change
            loadSections();
        }
    }
}
