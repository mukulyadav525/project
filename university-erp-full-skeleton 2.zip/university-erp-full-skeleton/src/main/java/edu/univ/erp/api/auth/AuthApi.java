package edu.univ.erp.api.auth;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.auth.AuthService;
import edu.univ.erp.domain.UserAccount;

public class AuthApi {

    private final AuthService authService = new AuthService();

    public ApiResponse<UserAccount> login(String username, String password) {
        if (username == null || password == null || username.isBlank() || password.isBlank()) {
            return ApiResponse.fail("Username and password must not be empty.");
        }

        UserAccount user = authService.login(username, password);
        if (user == null) {
            return ApiResponse.fail("Incorrect username or password.");
        }

        return ApiResponse.ok(user);
    }

    public ApiResponse<Void> logout() {
        authService.logout();
        return ApiResponse.ok(null);
    }
}
