package edu.univ.erp.api.admin;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.domain.Course;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.AdminService;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class AdminApi {

    private final AdminService adminService = new AdminService();

    // ========= Maintenance Mode =========

    /**
     * Backwards-compatible simple toggle (no custom banner).
     * Uses a default banner when turning ON; clears when OFF.
     */
    public ApiResponse<Void> toggleMaintenance(boolean on) {
        String banner = on ? "The system is currently under maintenance." : "";
        return setMaintenanceMode(on, banner);
    }

    /**
     * Toggle maintenance mode and set the banner message to be displayed.
     *
     * Expected AdminService:
     *  - void setMaintenanceMode(boolean on, String bannerMessage)
     */
    public ApiResponse<Void> setMaintenanceMode(boolean on, String bannerMessage) {
        adminService.setMaintenanceMode(on, bannerMessage);
        return ApiResponse.ok(null);
    }

    /**
     * Get current maintenance flag.
     *
     * Expected AdminService:
     *  - boolean isMaintenanceOn()
     */
    public ApiResponse<Boolean> getMaintenanceMode() {
        return ApiResponse.ok(adminService.isMaintenanceOn());
    }

    /**
     * Get current maintenance banner text.
     *
     * Expected AdminService:
     *  - String getMaintenanceBanner()
     */
    public ApiResponse<String> getMaintenanceBanner() {
        return ApiResponse.ok(adminService.getMaintenanceBanner());
    }

    // ========= Registration & Drop Deadlines =========
    //
    // These are for Admin UI to configure the rules that StudentApi + UI read.
    // Student side:
    //  - StudentApi.getRegistrationDeadline() / getDropDeadline()
    //  - StudentCatalogPanel, StudentRegistrationsPanel use those
    // Backend enforcement:
    //  - StudentApi.registerInSection() checks registration deadline
    //  - StudentApi.dropSection() checks drop deadline
    //
    // Here we expose admin endpoints that delegate to AdminService.
    // Expected AdminService:
    //  - void setRegistrationDeadline(LocalDateTime deadline)
    //  - LocalDateTime getRegistrationDeadline()
    //  - void setDropDeadline(LocalDateTime deadline)
    //  - LocalDateTime getDropDeadline()

    private static final DateTimeFormatter DEADLINE_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"); // ISO-like for input
    private static final DateTimeFormatter DISPLAY_FORMAT =
            DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a");

    /**
     * Set the registration deadline.
     *
     * @param isoDateTime expected in ISO-8601 format, e.g. 2025-11-30T23:59:00
     */
    public ApiResponse<Void> setRegistrationDeadline(String isoDateTime) {
        if (isoDateTime == null || isoDateTime.isBlank()) {
            return ApiResponse.fail("Deadline value is required.");
        }
        try {
            // Accept standard ISO-8601; if your DB stores as-is, this is consistent.
            LocalDateTime deadline = LocalDateTime.parse(isoDateTime);
            adminService.setRegistrationDeadline(deadline);
            return ApiResponse.ok(null);
        } catch (DateTimeParseException e) {
            return ApiResponse.fail("Invalid registration deadline format. Use ISO-8601 like 2025-11-30T23:59:00");
        }
    }

    /**
     * Get the registration deadline formatted for display.
     */
    public ApiResponse<String> getRegistrationDeadline() {
        LocalDateTime deadline = adminService.getRegistrationDeadline();
        if (deadline == null) {
            return ApiResponse.ok(null); // not configured
        }
        return ApiResponse.ok(deadline.format(DISPLAY_FORMAT));
    }

    /**
     * Set the drop deadline.
     *
     * @param isoDateTime expected in ISO-8601 format, e.g. 2025-12-15T23:59:00
     */
    public ApiResponse<Void> setDropDeadline(String isoDateTime) {
        if (isoDateTime == null || isoDateTime.isBlank()) {
            return ApiResponse.fail("Deadline value is required.");
        }
        try {
            LocalDateTime deadline = LocalDateTime.parse(isoDateTime);
            adminService.setDropDeadline(deadline);
            return ApiResponse.ok(null);
        } catch (DateTimeParseException e) {
            return ApiResponse.fail("Invalid drop deadline format. Use ISO-8601 like 2025-12-15T23:59:00");
        }
    }

    /**
     * Get the drop deadline formatted for display.
     */
    public ApiResponse<String> getDropDeadline() {
        LocalDateTime deadline = adminService.getDropDeadline();
        if (deadline == null) {
            return ApiResponse.ok(null); // not configured
        }
        return ApiResponse.ok(deadline.format(DISPLAY_FORMAT));
    }

    // ========= Courses =========

    public ApiResponse<Void> createCourse(Course c) {
        if (c == null) {
            return ApiResponse.error("Course cannot be null");
        }
        if (isEmpty(c.getCode()) || isEmpty(c.getTitle())) {
            return ApiResponse.error("Course code and title are required");
        }
        adminService.createCourse(c);
        return ApiResponse.ok(null);
    }

    /**
     * Update an existing course.
     *
     * Expected AdminService:
     *  - void updateCourse(Course c)
     */
    public ApiResponse<Void> updateCourse(Course c) {
        if (c == null || isEmpty(c.getCode())) {
            return ApiResponse.error("Course and course code are required");
        }
        adminService.updateCourse(c);
        return ApiResponse.ok(null);
    }

    /**
     * Delete a course by its code.
     *
     * Expected AdminService:
     *  - void deleteCourse(String code)
     */
    public ApiResponse<Void> deleteCourse(String code) {
        if (isEmpty(code)) {
            return ApiResponse.error("Course code is required");
        }
        adminService.deleteCourse(code);
        return ApiResponse.ok(null);
    }

    /**
     * List all courses for AdminCoursesPanel table.
     *
     * Expected AdminService:
     *  - List<Course> getAllCourses()
     */
    public ApiResponse<List<Course>> getAllCourses() {
        List<Course> courses = adminService.getAllCourses();
        return ApiResponse.ok(courses);
    }

    // ========= Sections =========

    public ApiResponse<Void> createSection(Section s) {
        if (s == null) {
            return ApiResponse.error("Section cannot be null");
        }
        adminService.createSection(s);
        return ApiResponse.ok(null);
    }

    /**
     * Update an existing section.
     *
     * Expected AdminService:
     *  - void updateSection(Section s)
     */
    public ApiResponse<Void> updateSection(Section s) {
        if (s == null || s.getId() == null) {
            return ApiResponse.error("Section and section ID are required");
        }
        adminService.updateSection(s);
        return ApiResponse.ok(null);
    }

    /**
     * Delete section by ID.
     *
     * Expected AdminService:
     *  - void deleteSection(long id)
     */
    public ApiResponse<Void> deleteSection(long sectionId) {
        adminService.deleteSection(sectionId);
        return ApiResponse.ok(null);
    }

    /**
     * List all sections.
     *
     * Expected AdminService:
     *  - List<Section> getAllSections()
     */
    public ApiResponse<List<Section>> getAllSections() {
        List<Section> sections = adminService.getAllSections();
        return ApiResponse.ok(sections);
    }

    /**
     * List sections for a specific course.
     *
     * Expected AdminService:
     *  - List<Section> getSectionsByCourse(String courseCode)
     */
    public ApiResponse<List<Section>> getSectionsByCourse(String courseCode) {
        if (isEmpty(courseCode)) {
            return ApiResponse.error("Course code is required");
        }
        List<Section> sections = adminService.getSectionsByCourse(courseCode);
        return ApiResponse.ok(sections);
    }

    // ========= Instructor Assignment =========

    public ApiResponse<Void> assignInstructor(long sectionId, long instructorId) {
        if (sectionId <= 0 || instructorId <= 0) {
            return ApiResponse.error("Valid sectionId and instructorId are required");
        }
        adminService.assignInstructor(sectionId, instructorId);
        return ApiResponse.ok(null);
    }

    // ========= Helpers =========

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }
}
