package edu.univ.erp.access;

import edu.univ.erp.auth.SessionContext;
import edu.univ.erp.domain.UserAccount;
import edu.univ.erp.service.MaintenanceService;

public class AccessControl {

    private static final MaintenanceService maintenanceService = new MaintenanceService();

    private AccessControl() {
        // Utility class: prevent instantiation
    }

    public static boolean isMaintenanceOn() {
        return maintenanceService.isMaintenanceOn();
    }

    public static boolean hasRole(String role) {
        if (role == null) {
            return false;
        }
        UserAccount u = SessionContext.getCurrentUser();
        return u != null && role.equalsIgnoreCase(u.getRole());
    }

    public static boolean canModifyForRole(String requiredRole) {
        if (requiredRole == null) {
            return false;
        }

        // During maintenance, only ADMIN-related modifications are allowed
        if (isMaintenanceOn() && !"ADMIN".equalsIgnoreCase(requiredRole)) {
            return false;
        }

        return hasRole(requiredRole);
    }
}
