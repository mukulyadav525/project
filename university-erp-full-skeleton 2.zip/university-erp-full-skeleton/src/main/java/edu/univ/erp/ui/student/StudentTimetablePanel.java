package edu.univ.erp.ui.student;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Student timetable view.
 *
 * - Displays a weekly grid: Time slots (rows) vs Mon-Fri (columns).
 * - Each cell shows the course (and optionally room) for that slot.
 * - Assumes standard pattern: 5 courses, each with 2 classes/week of 1.5 hrs.
 *
 * Backend integration:
 * - Replace loadTimetableFromBackend() with calls to your StudentApi /
 *   repository using the logged-in student id.
 * - When backend timetable changes, call reloadFromBackend() to refresh UI.
 */
public class StudentTimetablePanel extends JPanel {

    private static final String[] DAYS = {"Mon", "Tue", "Wed", "Thu", "Fri"};

    // 1.5 hr time slots (adjust as needed)
    private static final String[] TIME_SLOTS = {
            "09:00 - 10:30",
            "10:30 - 12:00",
            "13:00 - 14:30",
            "14:30 - 16:00"
    };

    private TimetableTableModel tableModel;
    private JTable table;

    public StudentTimetablePanel() {
        setLayout(new BorderLayout());

        JLabel header = new JLabel("My Weekly Timetable", SwingConstants.LEFT);
        header.setBorder(BorderFactory.createEmptyBorder(8, 8, 4, 8));
        header.setFont(header.getFont().deriveFont(java.awt.Font.BOLD, 16f));
        add(header, BorderLayout.NORTH);

        tableModel = new TimetableTableModel();
        table = new JTable(tableModel);
        table.setRowHeight(32);
        table.getTableHeader().setReorderingAllowed(false);
        table.setEnabled(false); // read-only for student

        table.getColumnModel().getColumn(0).setPreferredWidth(110);
        table.getColumnModel().getColumn(0).setMinWidth(110);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Initial data load
        reloadFromBackend();
    }

    /**
     * Public method to reload timetable when backend data changes.
     */
    public void reloadFromBackend() {
        List<TimetableEntry> entries = loadTimetableFromBackend();
        tableModel.setEntries(entries);
    }

    /**
     * TODO: Replace this stub with real data from backend.
     */
    private List<TimetableEntry> loadTimetableFromBackend() {
        List<TimetableEntry> list = new ArrayList<>();

        // Example courses – replace from StudentApi.getEnrolledCourses(studentId)
        String[][] courses = {
                {"CS101", "Intro to Programming", "LAB-1"},
                {"MA102", "Calculus II", "R-204"},
                {"EC103", "Microeconomics", "R-305"},
                {"HS104", "World History", "R-110"},
                {"EN105", "English Communication", "R-210"}
        };

        // Predefined {dayIndex, slotIndex} pairs: 2 per course
        int[][] positions = {
                {0, 0}, {2, 1}, // CS101
                {1, 0}, {3, 2}, // MA102
                {0, 1}, {4, 0}, // EC103
                {2, 0}, {4, 2}, // HS104
                {1, 2}, {3, 0}  // EN105
        };

        int posIdx = 0;
        for (String[] c : courses) {
            for (int k = 0; k < 2; k++) {
                int dayIdx = positions[posIdx][0];
                int slotIdx = positions[posIdx][1];
                posIdx++;

                list.add(new TimetableEntry(
                        DAYS[dayIdx],
                        TIME_SLOTS[slotIdx],
                        c[0],
                        c[1],
                        c[2]
                ));
            }
        }

        return list;
    }

    /**
     * One scheduled class.
     */
    private static class TimetableEntry {
        final String day;
        final String timeSlot;
        final String courseCode;
        final String courseTitle;
        final String room;

        TimetableEntry(String day, String timeSlot,
                       String courseCode, String courseTitle, String room) {
            this.day = day;
            this.timeSlot = timeSlot;
            this.courseCode = courseCode;
            this.courseTitle = courseTitle;
            this.room = room;
        }

        String cellText() {
            return courseCode + " (" + room + ")";
        }
    }

    /**
     * TableModel: col0 = Time, col1-5 = Mon-Fri.
     */
    private static class TimetableTableModel extends AbstractTableModel {

        private final String[] columns;
        private final String[][] grid; // [row=slot][col=day]

        TimetableTableModel() {
            columns = new String[DAYS.length + 1];
            columns[0] = "Time";
            System.arraycopy(DAYS, 0, columns, 1, DAYS.length);

            grid = new String[TIME_SLOTS.length][DAYS.length];
            clearGrid();
        }

        void setEntries(List<TimetableEntry> entries) {
            clearGrid();

            Map<String, Integer> timeIndex = new HashMap<>();
            for (int i = 0; i < TIME_SLOTS.length; i++) {
                timeIndex.put(TIME_SLOTS[i], i);
            }

            Map<String, Integer> dayIndex = new HashMap<>();
            for (int i = 0; i < DAYS.length; i++) {
                dayIndex.put(DAYS[i], i);
            }

            for (TimetableEntry e : entries) {
                Integer r = timeIndex.get(e.timeSlot);
                Integer c = dayIndex.get(e.day);
                if (r != null && c != null) {
                    grid[r][c] = e.cellText();
                }
            }

            fireTableDataChanged();
        }

        private void clearGrid() {
            for (int r = 0; r < TIME_SLOTS.length; r++) {
                Arrays.fill(grid[r], "");
            }
        }

        @Override
        public int getRowCount() {
            return TIME_SLOTS.length;
        }

        @Override
        public int getColumnCount() {
            return columns.length;
        }

        @Override
        public String getColumnName(int column) {
            return columns[column];
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            if (columnIndex == 0) {
                return TIME_SLOTS[rowIndex];
            }
            return grid[rowIndex][columnIndex - 1];
        }

        @Override
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return false;
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return String.class;
        }
    }
}
