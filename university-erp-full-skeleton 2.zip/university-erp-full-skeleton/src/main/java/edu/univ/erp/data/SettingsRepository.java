package edu.univ.erp.data;
import java.sql.*;
import java.time.LocalDateTime;
import edu.univ.erp.util.DbConnectionPool;

import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SettingsRepository {

    public boolean isMaintenanceOn() {
        final String sql = "SELECT value FROM settings WHERE `key` = 'maintenance'";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return "ON".equalsIgnoreCase(rs.getString("value"));
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to check maintenance mode", e);
        }

        return false;
    }

    public LocalDateTime getRegistrationDeadline() {
        final String sql = "SELECT setting_value FROM settings WHERE setting_key = 'REGISTRATION_DEADLINE'";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                String value = rs.getString("setting_value");
                if (value != null && !value.isBlank()) {
                    return LocalDateTime.parse(value); // stored as ISO-8601
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public LocalDateTime getDropDeadline() {
        final String sql = "SELECT setting_value FROM settings WHERE setting_key = 'DROP_DEADLINE'";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                String value = rs.getString("setting_value");
                if (value != null && !value.isBlank()) {
                    return LocalDateTime.parse(value); // stored as ISO-8601
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void setMaintenanceBanner(String banner) {
        final String sql = "UPDATE settings SET setting_value = ? WHERE setting_key = 'MAINTENANCE_BANNER'";
        // ... (standard JDBC update logic)
    }

    public String getMaintenanceBanner() {
        final String sql = "SELECT setting_value FROM settings WHERE setting_key = 'MAINTENANCE_BANNER'";
        // ... (standard JDBC query returning String)
    }


    public void setMaintenance(boolean on) {
        final String updateSql = "UPDATE settings SET value = ? WHERE `key` = 'maintenance'";
        final String insertSql = "INSERT INTO settings (`key`, value) VALUES ('maintenance', ?)";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection()) {
            // Try to update first
            try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setString(1, on ? "ON" : "OFF");
                int updated = ps.executeUpdate();

                // If no rows updated, insert the key-value pair
                if (updated == 0) {
                    try (PreparedStatement psInsert = conn.prepareStatement(insertSql)) {
                        psInsert.setString(1, on ? "ON" : "OFF");
                        psInsert.executeUpdate();
                    }
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to update maintenance flag", e);
        }
    }


}
