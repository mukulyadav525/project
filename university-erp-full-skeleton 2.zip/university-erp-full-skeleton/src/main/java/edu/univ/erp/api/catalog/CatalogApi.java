package edu.univ.erp.api.catalog;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.domain.Section;
import edu.univ.erp.service.CatalogService;

import java.util.List;

public class CatalogApi {

    private final CatalogService catalogService = new CatalogService();

    public ApiResponse<List<Section>> listSections() {
        List<Section> sections = catalogService.listAllSections();
        if (sections == null || sections.isEmpty()) {
            return ApiResponse.error("No sections found.");
        }
        return ApiResponse.ok(sections);
    }
}
