package edu.univ.erp.ui.instructor;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.api.instructor.InstructorApi;
import edu.univ.erp.domain.Section;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Panel for instructors to:
 * - Select one of their sections
 * - Define percentage weights for components (QUIZ/MIDTERM/FINAL/etc.) per section (stored in-memory)
 * - Enter/update component scores for an enrollment
 * - Compute a final grade for an enrollment using those weights
 *
 * Uses ONLY:
 *  - InstructorApi.mySections()
 *  - InstructorApi.enterScore(...)
 *  - InstructorApi.setFinalGrade(...)
 */
public class InstructorGradeEntryPanel extends JPanel {

    private final InstructorApi instructorApi = new InstructorApi();

    // Section selection
    private final JComboBox<Section> sectionCombo;
    private final JLabel sectionSummaryLabel;

    // Component weights per sectionId
    private final DefaultTableModel weightModel;
    private final JTable weightTable;
    private final JTextField weightComponentField;
    private final JTextField weightPercentField;
    private final JLabel totalWeightLabel;
    private final Map<Long, Map<String, Double>> sectionWeights = new LinkedHashMap<>();

    // Direct score entry
    private final JTextField enrollmentIdField;
    private final JTextField componentField;
    private final JTextField scoreField;

    public InstructorGradeEntryPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        // ===== Header =====
        JPanel header = new JPanel(new BorderLayout());
        JLabel title = new JLabel("Grade Entry & Final Computation");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        header.add(title, BorderLayout.NORTH);

        JLabel hint = new JLabel(
                "<html><i>Select a section, define component weights (e.g., 20/30/50), " +
                        "enter scores, and compute final grades using your rule.</i></html>"
        );
        hint.setFont(hint.getFont().deriveFont(Font.PLAIN, 11f));
        header.add(hint, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);

        // ===== Section selector =====
        JPanel sectionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        sectionPanel.add(new JLabel("Section:"));

        sectionCombo = new JComboBox<>();
        sectionCombo.setPreferredSize(new Dimension(260, 24));
        sectionCombo.addActionListener(e -> onSectionChanged());
        sectionPanel.add(sectionCombo);

        JButton refreshSectionsBtn = new JButton("Refresh Sections");
        refreshSectionsBtn.addActionListener(e -> loadSections());
        sectionPanel.add(refreshSectionsBtn);

        sectionSummaryLabel = new JLabel(" ");
        sectionSummaryLabel.setFont(sectionSummaryLabel.getFont().deriveFont(Font.PLAIN, 11f));

        JPanel sectionWrapper = new JPanel(new BorderLayout());
        sectionWrapper.add(sectionPanel, BorderLayout.WEST);
        sectionWrapper.add(sectionSummaryLabel, BorderLayout.SOUTH);

        add(sectionWrapper, BorderLayout.BEFORE_FIRST_LINE);

        // ===== Center: left (weights) + right (scores/final) =====
        JPanel center = new JPanel(new GridLayout(1, 2, 10, 0));

        // ---------- Left: Weights ----------
        JPanel weightsPanel = new JPanel(new BorderLayout(5, 5));
        weightsPanel.setBorder(BorderFactory.createTitledBorder("Component Weights (%)"));

        weightModel = new DefaultTableModel(
                new Object[]{"Component", "Weight (%)"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        weightTable = new JTable(weightModel);
        weightTable.setFillsViewportHeight(true);
        JScrollPane weightScroll = new JScrollPane(weightTable);
        weightsPanel.add(weightScroll, BorderLayout.CENTER);

        JPanel weightForm = new JPanel(new GridLayout(3, 2, 4, 4));
        weightComponentField = new JTextField();
        weightPercentField = new JTextField();

        weightForm.add(new JLabel("Component (e.g., QUIZ, MIDTERM, FINAL):"));
        weightForm.add(weightComponentField);
        weightForm.add(new JLabel("Weight (%):"));
        weightForm.add(weightPercentField);

        JButton addUpdateBtn = new JButton("Add / Update");
        addUpdateBtn.addActionListener(e -> addOrUpdateComponentWeight());
        JButton removeBtn = new JButton("Remove Selected");
        removeBtn.addActionListener(e -> removeSelectedWeightRow());

        JPanel weightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        weightButtons.add(addUpdateBtn);
        weightButtons.add(removeBtn);

        weightsPanel.add(weightForm, BorderLayout.NORTH);
        weightsPanel.add(weightButtons, BorderLayout.SOUTH);

        JPanel weightFooter = new JPanel(new BorderLayout());
        totalWeightLabel = new JLabel("Total: 0%");
        totalWeightLabel.setFont(totalWeightLabel.getFont().deriveFont(Font.BOLD, 11f));

        JLabel localNote = new JLabel(
                "<html><small>Note: Weights are tracked per section in this screen and " +
                        "used when computing final grades.</small></html>"
        );

        JPanel leftFooter = new JPanel(new BorderLayout());
        leftFooter.add(totalWeightLabel, BorderLayout.WEST);
        leftFooter.add(localNote, BorderLayout.SOUTH);

        weightFooter.add(leftFooter, BorderLayout.WEST);
        weightsPanel.add(weightFooter, BorderLayout.PAGE_END);

        center.add(weightsPanel);

        // ---------- Right: Score entry + final compute ----------
        JPanel scorePanel = new JPanel(new BorderLayout(5, 5));
        scorePanel.setBorder(BorderFactory.createTitledBorder("Enter Scores & Compute Final"));

        JPanel scoreForm = new JPanel(new GridLayout(4, 2, 6, 6));
        enrollmentIdField = new JTextField();
        componentField = new JTextField();
        scoreField = new JTextField();

        scoreForm.add(new JLabel("Enrollment ID:"));
        scoreForm.add(enrollmentIdField);
        scoreForm.add(new JLabel("Component:"));
        scoreForm.add(componentField);
        scoreForm.add(new JLabel("Score:"));
        scoreForm.add(scoreField);

        JButton saveScoreButton = new JButton("Save Component Score");
        saveScoreButton.addActionListener(e -> saveScore());
        scoreForm.add(new JLabel()); // spacer
        scoreForm.add(saveScoreButton);

        scorePanel.add(scoreForm, BorderLayout.NORTH);

        JButton computeFinalBtn = new JButton("Compute Final for Enrollment (using weights)");
        computeFinalBtn.addActionListener(e -> computeFinalForEnrollment());
        scorePanel.add(computeFinalBtn, BorderLayout.CENTER);

        JLabel note = new JLabel(
                "<html><small>Final = Σ(score × weight/100) using the current section's components.<br>" +
                        "Component scores entered during this process are also stored.</small></html>"
        );
        scorePanel.add(note, BorderLayout.SOUTH);

        center.add(scorePanel);

        add(center, BorderLayout.CENTER);

        // Initial load
        loadSections();
    }

    // ===================== Section Handling =====================

    private void loadSections() {
        sectionCombo.removeAllItems();
        sectionSummaryLabel.setText("Loading sections...");

        ApiResponse<List<Section>> resp = instructorApi.mySections();

        if (!resp.isSuccess()) {
            sectionSummaryLabel.setText(" ");
            if (resp.getMessage() != null && !resp.getMessage().isBlank()) {
                JOptionPane.showMessageDialog(
                        this,
                        resp.getMessage(),
                        "Error Loading Sections",
                        JOptionPane.ERROR_MESSAGE
                );
            }
            return;
        }

        List<Section> sections = resp.getData();
        if (sections == null || sections.isEmpty()) {
            sectionSummaryLabel.setText("No sections assigned to you.");
            return;
        }

        for (Section s : sections) {
            sectionCombo.addItem(s);
        }

        sectionSummaryLabel.setText(sections.size() + " section(s) available.");
        if (sectionCombo.getItemCount() > 0) {
            sectionCombo.setSelectedIndex(0);
            onSectionChanged();
        }
    }

    private void onSectionChanged() {
        Long sectionId = getSelectedSectionId();
        clearWeightsTable();
        if (sectionId == null) return;

        Map<String, Double> weights = sectionWeights.get(sectionId);
        if (weights != null) {
            for (Map.Entry<String, Double> e : weights.entrySet()) {
                weightModel.addRow(new Object[]{e.getKey(), e.getValue()});
            }
        }
        updateTotalWeightLabel();
    }

    private Long getSelectedSectionId() {
        Object sel = sectionCombo.getSelectedItem();
        if (!(sel instanceof Section)) return null;

        Section section = (Section) sel;
        // Works for both long and Long (auto-unboxing if needed)
        long id = section.getSectionId();
        return (id > 0) ? id : null;
    }

    // ===================== Weights Logic =====================

    private void addOrUpdateComponentWeight() {
        Long sectionId = getSelectedSectionId();
        if (sectionId == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a valid section first.",
                    "No Section Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String comp = weightComponentField.getText().trim();
        String pctText = weightPercentField.getText().trim();

        if (comp.isEmpty() || pctText.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Component and Weight are required.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        try {
            double pct = Double.parseDouble(pctText);
            if (pct <= 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Weight must be greater than 0.",
                        "Validation Error",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            String name = comp.toUpperCase();
            boolean updated = false;

            for (int i = 0; i < weightModel.getRowCount(); i++) {
                String existing = String.valueOf(weightModel.getValueAt(i, 0));
                if (existing.equalsIgnoreCase(name)) {
                    weightModel.setValueAt(pct, i, 1);
                    updated = true;
                    break;
                }
            }

            if (!updated) {
                weightModel.addRow(new Object[]{name, pct});
            }

            storeWeightsForSection(sectionId);
            updateTotalWeightLabel();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Weight must be a valid numeric value.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void removeSelectedWeightRow() {
        int row = weightTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Select a row to remove.",
                    "No Selection",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }
        int modelRow = weightTable.convertRowIndexToModel(row);
        weightModel.removeRow(modelRow);

        Long sectionId = getSelectedSectionId();
        if (sectionId != null) {
            storeWeightsForSection(sectionId);
        }
        updateTotalWeightLabel();
    }

    private void storeWeightsForSection(Long sectionId) {
        Map<String, Double> weights = new LinkedHashMap<>();
        for (int i = 0; i < weightModel.getRowCount(); i++) {
            String name = String.valueOf(weightModel.getValueAt(i, 0));
            Object val = weightModel.getValueAt(i, 1);
            if (name == null || name.isBlank() || val == null) continue;
            double pct = (val instanceof Number)
                    ? ((Number) val).doubleValue()
                    : Double.parseDouble(val.toString());
            weights.put(name, pct);
        }
        sectionWeights.put(sectionId, weights);
    }

    private void clearWeightsTable() {
        weightModel.setRowCount(0);
        updateTotalWeightLabel();
    }

    private void updateTotalWeightLabel() {
        double total = 0.0;
        for (int i = 0; i < weightModel.getRowCount(); i++) {
            Object val = weightModel.getValueAt(i, 1);
            if (val == null) continue;
            try {
                double pct = (val instanceof Number)
                        ? ((Number) val).doubleValue()
                        : Double.parseDouble(val.toString());
                total += pct;
            } catch (NumberFormatException ignored) {
            }
        }
        totalWeightLabel.setText("Total: " + String.format("%.2f", total) + "%");
    }

    // ===================== Direct Score Entry =====================

    private void saveScore() {
        String eidText = enrollmentIdField.getText().trim();
        String comp = componentField.getText().trim();
        String scoreText = scoreField.getText().trim();

        if (eidText.isEmpty() || comp.isEmpty() || scoreText.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "All fields are required.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        try {
            long eid = Long.parseLong(eidText);
            double score = Double.parseDouble(scoreText);

            if (eid <= 0 || score < 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Enrollment ID must be positive and score cannot be negative.",
                        "Validation Error",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            ApiResponse<Void> resp = instructorApi.enterScore(
                    eid,
                    comp.trim().toUpperCase(),
                    score
            );

            JOptionPane.showMessageDialog(
                    this,
                    resp.isSuccess()
                            ? "Component score saved successfully."
                            : (resp.getMessage() != null ? resp.getMessage() : "Failed to save score."),
                    resp.isSuccess() ? "Success" : "Error",
                    resp.isSuccess() ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
            );

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Enrollment ID and Score must be valid numeric values.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // ===================== Final Grade Computation =====================

    private void computeFinalForEnrollment() {
        Long sectionId = getSelectedSectionId();
        if (sectionId == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a valid section first.",
                    "No Section Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        Map<String, Double> weights = sectionWeights.get(sectionId);
        if (weights == null || weights.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Define at least one component weight for this section.",
                    "No Weights Defined",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        double total = weights.values().stream().mapToDouble(Double::doubleValue).sum();
        if (Math.abs(total - 100.0) > 0.0001) {
            JOptionPane.showMessageDialog(
                    this,
                    "Total weight must be exactly 100% (current: " + total + "%).",
                    "Invalid Weights",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String eidText = JOptionPane.showInputDialog(
                this,
                "Enter Enrollment ID to compute final for:",
                "Compute Final Grade",
                JOptionPane.QUESTION_MESSAGE
        );
        if (eidText == null || eidText.trim().isEmpty()) {
            return; // cancelled
        }

        long enrollmentId;
        try {
            enrollmentId = Long.parseLong(eidText.trim());
            if (enrollmentId <= 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Enrollment ID must be a positive number.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        double finalScore = 0.0;

        // For each component, prompt, store via enterScore, and accumulate weighted score.
        for (Map.Entry<String, Double> e : weights.entrySet()) {
            String comp = e.getKey();
            double w = e.getValue();

            String scoreStr = JOptionPane.showInputDialog(
                    this,
                    "Enter score for " + comp + " (Enrollment " + enrollmentId + "):",
                    "Component Score",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (scoreStr == null) {
                JOptionPane.showMessageDialog(
                        this,
                        "Final grade computation cancelled.",
                        "Cancelled",
                        JOptionPane.INFORMATION_MESSAGE
                );
                return;
            }

            double score;
            try {
                score = Double.parseDouble(scoreStr.trim());
                if (score < 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(
                        this,
                        "Invalid score for component " + comp + ".",
                        "Input Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            ApiResponse<Void> scoreResp = instructorApi.enterScore(enrollmentId, comp, score);
            if (!scoreResp.isSuccess()) {
                JOptionPane.showMessageDialog(
                        this,
                        scoreResp.getMessage() != null ? scoreResp.getMessage()
                                : "Failed to save score for component " + comp + ".",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            finalScore += score * (w / 100.0);
        }

        ApiResponse<Void> finalResp = instructorApi.setFinalGrade(enrollmentId, finalScore);
        if (finalResp.isSuccess()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Final grade (" + String.format("%.2f", finalScore) +
                            ") saved for enrollment " + enrollmentId + ".",
                    "Final Grade Saved",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    finalResp.getMessage() != null ? finalResp.getMessage()
                            : "Failed to save final grade.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}
