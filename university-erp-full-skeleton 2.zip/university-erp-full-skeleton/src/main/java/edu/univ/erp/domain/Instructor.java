package edu.univ.erp.domain;

public class Instructor {

    private long instructorId;
    private long userId;
    private String department;

    public Instructor() {
    }

    public Instructor(long instructorId, long userId, String department) {
        this.instructorId = instructorId;
        this.userId = userId;
        this.department = department;
    }

    public long getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(long instructorId) {
        this.instructorId = instructorId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Instructor{" +
                "instructorId=" + instructorId +
                ", userId=" + userId +
                ", department='" + department + '\'' +
                '}';
    }
}
