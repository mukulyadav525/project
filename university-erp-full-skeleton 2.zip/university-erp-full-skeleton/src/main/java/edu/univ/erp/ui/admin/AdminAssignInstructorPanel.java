package edu.univ.erp.ui.admin;

import edu.univ.erp.api.admin.AdminApi;
import edu.univ.erp.api.common.ApiResponse;

import javax.swing.*;
import java.awt.*;

public class AdminAssignInstructorPanel extends JPanel {

    private final AdminApi adminApi = new AdminApi();

    private final JTextField sectionIdField;
    private final JTextField instructorIdField;
    private final JButton assignButton;
    private final JButton clearButton;

    public AdminAssignInstructorPanel() {
        setLayout(new BorderLayout(8, 8));

        // ===== Form =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        sectionIdField = new JTextField(10);
        instructorIdField = new JTextField(10);

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Section ID:"), gbc);
        gbc.gridx = 1;
        formPanel.add(sectionIdField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Instructor ID:"), gbc);
        gbc.gridx = 1;
        formPanel.add(instructorIdField, gbc);

        // ===== Buttons =====
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        assignButton = new JButton("Assign Instructor");
        clearButton = new JButton("Clear");

        buttonsPanel.add(assignButton);
        buttonsPanel.add(clearButton);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        formPanel.add(buttonsPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        // Info label (optional helper text)
        JLabel info = new JLabel(
                "<html>Assign an instructor to a section by their IDs.<br>" +
                        "These IDs should match existing Section and Instructor records.</html>"
        );
        add(info, BorderLayout.CENTER);

        // ===== Listeners =====
        assignButton.addActionListener(e -> onAssign());
        clearButton.addActionListener(e -> clearForm());
    }

    private void onAssign() {
        String sidText = sectionIdField.getText().trim();
        String iidText = instructorIdField.getText().trim();

        if (sidText.isEmpty() || iidText.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Both Section ID and Instructor ID are required.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        long sectionId;
        long instructorId;
        try {
            sectionId = Long.parseLong(sidText);
            instructorId = Long.parseLong(iidText);

            if (sectionId <= 0 || instructorId <= 0) {
                throw new NumberFormatException("IDs must be positive.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter valid positive numeric IDs for Section and Instructor.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        ApiResponse<Void> resp = adminApi.assignInstructor(sectionId, instructorId);

        JOptionPane.showMessageDialog(
                this,
                resp.isSuccess() ? "Instructor assigned to section successfully." : resp.getMessage(),
                resp.isSuccess() ? "Success" : "Error",
                resp.isSuccess() ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
        );

        if (resp.isSuccess()) {
            clearForm();
        }
    }

    private void clearForm() {
        sectionIdField.setText("");
        instructorIdField.setText("");
    }
}
