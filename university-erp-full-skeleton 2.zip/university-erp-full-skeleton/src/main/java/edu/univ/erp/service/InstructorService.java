package edu.univ.erp.service;

import edu.univ.erp.auth.SessionContext;
import edu.univ.erp.data.EnrollmentRepository;
import edu.univ.erp.data.GradeRepository;
import edu.univ.erp.data.InstructorRepository;
import edu.univ.erp.data.SectionRepository;
import edu.univ.erp.domain.Instructor;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.UserAccount;
import edu.univ.erp.domain.SectionStats;

import java.util.List;

public class InstructorService {

    private final InstructorRepository instructorRepository = new InstructorRepository();
    private final SectionRepository sectionRepository = new SectionRepository();
    private final EnrollmentRepository enrollmentRepository = new EnrollmentRepository();
    private final GradeRepository gradeRepository = new GradeRepository();
    private final MaintenanceService maintenanceService = new MaintenanceService();

    /**
     * Get the current instructor based on the logged-in user.
     * Returns null if not logged in, not INSTRUCTOR role, or no instructor record.
     */
    private Instructor currentInstructorOrError() {
        UserAccount u = SessionContext.getCurrentUser();
        if (u == null || !"INSTRUCTOR".equalsIgnoreCase(u.getRole())) {
            return null;
        }
        return instructorRepository.findByUserId(u.getUserId());
    }

    /**
     * Get all sections assigned to the currently logged-in instructor.
     * Returns an empty list if not authorized or none found.
     */
    public List<Section> getMySections() {
        Instructor instructor = currentInstructorOrError();
        if (instructor == null) {
            return List.of();
        }
        return sectionRepository.findByInstructor(instructor.getInstructorId());
    }

    /**
     * Enter or update a component score for an enrollment.
     *
     * @return null on success, or an error message string.
     */
    public String enterScore(long enrollmentId, String component, double score) {
        if (maintenanceService.isMaintenanceOn()) {
            return "Grades cannot be edited: maintenance mode is ON.";
        }

        Instructor instructor = currentInstructorOrError();
        if (instructor == null) {
            return "Not authorized: only instructors can enter scores.";
        }

        if (enrollmentId <= 0) {
            return "Invalid enrollment ID.";
        }
        if (component == null || component.isBlank()) {
            return "Component name cannot be empty.";
        }
        if (score < 0) {
            return "Score cannot be negative.";
        }

        // NOTE: In a full implementation, verify that:
        // - the enrollment exists
        // - the enrollment's section belongs to this instructor.
        // This requires joining enrollment -> section -> instructor.
        // The check is omitted here for brevity.

        gradeRepository.upsertComponent(enrollmentId, component, score);
        return null;
    }

    /**
     * Set the final grade for an enrollment.
     *
     * @return null on success, or an error message string.
     */
    public String setFinalGrade(long enrollmentId, double finalScore) {
        if (maintenanceService.isMaintenanceOn()) {
            return "Grades cannot be edited: maintenance mode is ON.";
        }

        Instructor instructor = currentInstructorOrError();
        if (instructor == null) {
            return "Not authorized: only instructors can set final grades.";
        }

        if (enrollmentId <= 0) {
            return "Invalid enrollment ID.";
        }
        if (finalScore < 0) {
            return "Final score cannot be negative.";
        }

        // Same note as above: in a complete system, validate ownership of the enrollment.

        gradeRepository.setFinalGrade(enrollmentId, finalScore);
        return null;
    }
    public SectionStats getSectionStats(long sectionId) {
        // TODO: compute from your enrollments / grades table.
        // For now you can return null or dummy data.
        return null;
    }

    // TODO: Add stats / reporting helpers (e.g., section averages) using gradeRepository.
}
