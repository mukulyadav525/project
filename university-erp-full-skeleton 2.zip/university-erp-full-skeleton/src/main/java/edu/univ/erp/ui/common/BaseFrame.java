package edu.univ.erp.ui.common;

import edu.univ.erp.api.maintenance.MaintenanceApi;
import edu.univ.erp.auth.SessionContext;

import javax.swing.*;
import java.awt.*;

/**
 * Base frame for all application dashboards (Admin, Student, Instructor).
 * Shows a maintenance banner and (for Admin) a toggle button to turn it ON/OFF.
 */
public abstract class BaseFrame extends JFrame {

    private final MaintenanceApi maintenanceApi = new MaintenanceApi();

    private JLabel banner;
    private JToggleButton maintenanceToggle;

    public BaseFrame(String title) {
        super(title);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        // Use BorderLayout so header sits at NORTH and screens at CENTER
        getContentPane().setLayout(new BorderLayout());

        initHeader();
    }

    /**
     * Creates the top header with:
     * - maintenance banner (visible only when ON)
     * - maintenance toggle button (visible only for Admin)
     */
    private void initHeader() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));

        // Banner label (center)
        banner = new JLabel(
                "⚙ Maintenance Mode is ON – Some features may be unavailable",
                SwingConstants.CENTER
        );
        banner.setFont(new Font("SansSerif", Font.BOLD, 14));
        banner.setForeground(Color.BLACK);
        banner.setOpaque(true);
        banner.setBackground(new Color(255, 204, 0)); // orange strip
        banner.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        banner.setVisible(maintenanceApi.isMaintenanceOn());

        // Toggle (right)
        maintenanceToggle = new JToggleButton("Toggle");
        maintenanceToggle.setSelected(maintenanceApi.isMaintenanceOn());
        maintenanceToggle.addActionListener(e -> onToggleClicked());

        // TODO: adjust this line to your actual SessionContext API
        boolean isAdmin = "ADMIN".equalsIgnoreCase(SessionContext.getCurrentUser().getRole());
        maintenanceToggle.setVisible(isAdmin);

        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(new JLabel("Maintenance:"));
        rightPanel.add(maintenanceToggle);

        headerPanel.add(banner, BorderLayout.CENTER);
        headerPanel.add(rightPanel, BorderLayout.EAST);

        getContentPane().add(headerPanel, BorderLayout.NORTH);
    }

    /**
     * Called when the toggle is clicked.
     * Updates maintenance flag and UI.
     */
    private void onToggleClicked() {
        // Safety: do not allow non-admin to change (in case of misuse)
        if (!"ADMIN".equalsIgnoreCase(SessionContext.getCurrentUser().getRole())) {
            JOptionPane.showMessageDialog(
                    this,
                    "Only Admin can change maintenance mode.",
                    "Not allowed",
                    JOptionPane.WARNING_MESSAGE
            );
            maintenanceToggle.setSelected(maintenanceApi.isMaintenanceOn());
            return;
        }

        boolean newState = maintenanceToggle.isSelected();
        maintenanceApi.setMaintenanceMode(newState);   // uses your existing API
        refreshBanner();

        JOptionPane.showMessageDialog(
                this,
                newState
                        ? "Maintenance mode is now ON. Some operations are disabled."
                        : "Maintenance mode is now OFF. Normal operations resumed.",
                "Maintenance",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    /**
     * Syncs banner + toggle with current maintenance state.
     * Can be called by other components if they change the flag.
     */
    protected void refreshBanner() {
        boolean on = maintenanceApi.isMaintenanceOn();
        banner.setVisible(on);
        maintenanceToggle.setSelected(on);
    }
}
