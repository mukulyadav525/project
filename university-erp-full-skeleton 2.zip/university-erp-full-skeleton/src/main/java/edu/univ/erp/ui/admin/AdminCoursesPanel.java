package edu.univ.erp.ui.admin;

import edu.univ.erp.api.admin.AdminApi;
import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.domain.Course;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminCoursesPanel extends JPanel {

    private final AdminApi adminApi = new AdminApi();

    private final JTextField codeField;
    private final JTextField titleField;
    private final JTextField creditsField;

    private final JButton createButton;
    private final JButton updateButton;
    private final JButton deleteButton;
    private final JButton clearButton;

    private final JTable coursesTable;
    private final DefaultTableModel tableModel;

    public AdminCoursesPanel() {
        setLayout(new BorderLayout(8, 8));

        // === Form ===
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        codeField = new JTextField(15);
        titleField = new JTextField(25);
        creditsField = new JTextField(5);

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Course Code:"), gbc);
        gbc.gridx = 1;
        formPanel.add(codeField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Title:"), gbc);
        gbc.gridx = 1;
        formPanel.add(titleField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Credits:"), gbc);
        gbc.gridx = 1;
        formPanel.add(creditsField, gbc);

        // === Buttons ===
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        createButton = new JButton("Create");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear");

        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);

        buttonPanel.add(createButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        // === Table ===
        tableModel = new DefaultTableModel(new Object[]{"Code", "Title", "Credits"}, 0) {
            @Override
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false; // editing only through form
            }
        };

        coursesTable = new JTable(tableModel);
        coursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        coursesTable.setRowHeight(22);

        add(new JScrollPane(coursesTable), BorderLayout.CENTER);

        // === Listeners ===
        createButton.addActionListener(e -> onCreate());
        updateButton.addActionListener(e -> onUpdate());
        deleteButton.addActionListener(e -> onDelete());
        clearButton.addActionListener(e -> clearForm());

        coursesTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                onTableSelectionChanged();
            }
        });

        // Initial load
        loadCourses();
    }

    private void onCreate() {
        String code = codeField.getText().trim();
        String title = titleField.getText().trim();
        String creditsText = creditsField.getText().trim();

        if (!validateInputs(code, title, creditsText)) {
            return;
        }

        int credits = Integer.parseInt(creditsText);

        Course course = new Course();
        course.setCode(code);
        course.setTitle(title);
        course.setCredits(credits);

        ApiResponse<Void> resp = adminApi.createCourse(course);

        if (resp.isSuccess()) {
            JOptionPane.showMessageDialog(this, "Course created successfully.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            loadCourses();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, resp.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onUpdate() {
        int selectedRow = coursesTable.getSelectedRow();
        if (selectedRow == -1) return;

        String originalCode = (String) tableModel.getValueAt(selectedRow, 0);

        String code = codeField.getText().trim();
        String title = titleField.getText().trim();
        String creditsText = creditsField.getText().trim();

        if (!validateInputs(code, title, creditsText)) {
            return;
        }

        int credits = Integer.parseInt(creditsText);

        Course course = new Course();
        course.setCode(code);
        course.setTitle(title);
        course.setCredits(credits);

        // If your API expects original code separately, adapt this call accordingly.
        ApiResponse<Void> resp = adminApi.updateCourse(course);

        if (resp.isSuccess()) {
            JOptionPane.showMessageDialog(this, "Course updated successfully.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            loadCourses();
            // Re-select updated row if code unchanged
            selectRowByCode(code != null ? code : originalCode);
        } else {
            JOptionPane.showMessageDialog(this, resp.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onDelete() {
        int selectedRow = coursesTable.getSelectedRow();
        if (selectedRow == -1) return;

        String code = (String) tableModel.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete course \"" + code + "\"?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        ApiResponse<Void> resp = adminApi.deleteCourse(code);

        if (resp.isSuccess()) {
            JOptionPane.showMessageDialog(this, "Course deleted successfully.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            loadCourses();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, resp.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onTableSelectionChanged() {
        int row = coursesTable.getSelectedRow();
        if (row == -1) {
            updateButton.setEnabled(false);
            deleteButton.setEnabled(false);
            return;
        }

        String code = (String) tableModel.getValueAt(row, 0);
        String title = (String) tableModel.getValueAt(row, 1);
        Integer credits = (Integer) tableModel.getValueAt(row, 2);

        codeField.setText(code);
        titleField.setText(title);
        creditsField.setText(String.valueOf(credits));

        updateButton.setEnabled(true);
        deleteButton.setEnabled(true);
    }

    private void clearForm() {
        codeField.setText("");
        titleField.setText("");
        creditsField.setText("");
        coursesTable.clearSelection();
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    private boolean validateInputs(String code, String title, String creditsText) {
        if (code.isEmpty() || title.isEmpty() || creditsText.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "All fields (Code, Title, Credits) are required.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE
            );
            return false;
        }

        try {
            int credits = Integer.parseInt(creditsText);
            if (credits < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Credits must be a valid non-negative integer.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        }

        return true;
    }

    private void loadCourses() {
        tableModel.setRowCount(0);

        ApiResponse<List<Course>> resp = adminApi.getAllCourses();
        if (!resp.isSuccess()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to load courses: " + resp.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        List<Course> courses = resp.getData();
        if (courses == null) return;

        for (Course c : courses) {
            tableModel.addRow(new Object[]{
                    c.getCode(),
                    c.getTitle(),
                    c.getCredits()
            });
        }
    }

    private void selectRowByCode(String code) {
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if (code.equals(tableModel.getValueAt(i, 0))) {
                coursesTable.setRowSelectionInterval(i, i);
                break;
            }
        }
    }
}
