package edu.univ.erp.api.instructor;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.SectionStats;
import edu.univ.erp.service.InstructorService;

import java.util.List;

public class InstructorApi {

    private final InstructorService instructorService = new InstructorService();

    public ApiResponse<List<Section>> mySections() {
        List<Section> sections = instructorService.getMySections();
        if (sections == null || sections.isEmpty()) {
            return ApiResponse.error("No sections found for the current instructor.");
        }
        return ApiResponse.ok(sections);
    }

    public ApiResponse<Void> enterScore(long enrollmentId, String component, double score) {
        if (component == null || component.isBlank()) {
            return ApiResponse.fail("Score component name cannot be empty.");
        }
        if (score < 0) {
            return ApiResponse.fail("Score cannot be negative.");
        }

        String err = instructorService.enterScore(enrollmentId, component.trim().toUpperCase(), score);
        return (err == null) ? ApiResponse.ok(null) : ApiResponse.fail(err);
    }

    public ApiResponse<Void> setFinalGrade(long enrollmentId, double finalScore) {
        if (finalScore < 0) {
            return ApiResponse.fail("Final score cannot be negative.");
        }

        String err = instructorService.setFinalGrade(enrollmentId, finalScore);
        return (err == null) ? ApiResponse.ok(null) : ApiResponse.fail(err);
    }

    // NEW: stats for a section, used by InstructorStatsPanel
    public ApiResponse<SectionStats> sectionStats(long sectionId) {
        if (sectionId <= 0) {
            return ApiResponse.fail("Invalid section ID.");
        }

        SectionStats stats = instructorService.getSectionStats(sectionId);
        if (stats == null) {
            return ApiResponse.error("No statistics available for section " + sectionId + ".");
        }
        return ApiResponse.ok(stats);
    }
}
