package edu.univ.erp.ui.admin;

import edu.univ.erp.api.admin.AdminApi;
import edu.univ.erp.api.common.ApiResponse;

import javax.swing.*;
import java.awt.*;

public class AdminMaintenancePanel extends JPanel {

    private final AdminApi adminApi = new AdminApi();

    private final JCheckBox maintenanceCheck;
    private final JTextArea bannerArea;
    private final JLabel statusLabel;
    private final JButton applyButton;
    private final JButton refreshButton;

    public AdminMaintenancePanel() {
        setLayout(new BorderLayout(10, 10));

        // ===== Top: Status + Toggle =====
        JPanel topPanel = new JPanel(new BorderLayout(8, 8));

        maintenanceCheck = new JCheckBox("Maintenance Mode (ON/OFF)");
        statusLabel = new JLabel("Loading maintenance status...");
        statusLabel.setForeground(Color.DARK_GRAY);

        topPanel.add(maintenanceCheck, BorderLayout.WEST);
        topPanel.add(statusLabel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // ===== Center: Banner Text =====
        JPanel bannerPanel = new JPanel(new BorderLayout(5, 5));
        bannerPanel.setBorder(BorderFactory.createTitledBorder("Maintenance Banner Message"));

        bannerArea = new JTextArea(5, 40);
        bannerArea.setLineWrap(true);
        bannerArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(bannerArea);
        bannerPanel.add(new JLabel("Message shown to users when maintenance is ON:"), BorderLayout.NORTH);
        bannerPanel.add(scrollPane, BorderLayout.CENTER);

        add(bannerPanel, BorderLayout.CENTER);

        // ===== Bottom: Actions =====
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        applyButton = new JButton("Apply");
        refreshButton = new JButton("Refresh");

        buttonsPanel.add(refreshButton);
        buttonsPanel.add(applyButton);

        add(buttonsPanel, BorderLayout.SOUTH);

        // ===== Listeners =====
        applyButton.addActionListener(e -> onApply());
        refreshButton.addActionListener(e -> loadState());

        // Initial load
        loadState();
    }

    private void onApply() {
        boolean on = maintenanceCheck.isSelected();
        String banner = bannerArea.getText().trim();

        // Provide a sensible default if turning ON without a message
        if (on && banner.isEmpty()) {
            banner = "The system is currently under maintenance. Please try again later.";
        }

        ApiResponse<Void> resp = adminApi.setMaintenanceMode(on, banner);

        if (resp.isSuccess()) {
            JOptionPane.showMessageDialog(
                    this,
                    on ? "Maintenance mode enabled with updated banner."
                            : "Maintenance mode disabled.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );
            updateStatusLabel(on, banner);
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    resp.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loadState() {
        // Get ON/OFF
        ApiResponse<Boolean> modeResp = adminApi.getMaintenanceMode();
        boolean on = modeResp.isSuccess() && Boolean.TRUE.equals(modeResp.getData());

        // Get banner
        ApiResponse<String> bannerResp = adminApi.getMaintenanceBanner();
        String banner = bannerResp.isSuccess() && bannerResp.getData() != null
                ? bannerResp.getData()
                : "";

        maintenanceCheck.setSelected(on);
        bannerArea.setText(banner);
        updateStatusLabel(on, banner);

        if (!modeResp.isSuccess() || !bannerResp.isSuccess()) {
            String msg = "Warning: Unable to fully load maintenance state.";
            if (!modeResp.isSuccess()) {
                msg += "\n- Mode: " + modeResp.getMessage();
            }
            if (!bannerResp.isSuccess()) {
                msg += "\n- Banner: " + bannerResp.getMessage();
            }
            JOptionPane.showMessageDialog(
                    this,
                    msg,
                    "Load Warning",
                    JOptionPane.WARNING_MESSAGE
            );
        }
    }

    private void updateStatusLabel(boolean on, String banner) {
        if (on) {
            statusLabel.setText("Status: MAINTENANCE MODE ON");
            statusLabel.setForeground(new Color(178, 34, 34)); // dark red-ish
        } else {
            statusLabel.setText("Status: Maintenance mode OFF");
            statusLabel.setForeground(new Color(0, 128, 0)); // green-ish
        }
    }
}
