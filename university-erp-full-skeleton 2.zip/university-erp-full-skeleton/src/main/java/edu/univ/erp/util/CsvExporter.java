package edu.univ.erp.util;

import java.io.FileWriter;
import java.util.List;

public class CsvExporter {
    public static void export(String path, List<String[]> rows) {
        try (FileWriter fw = new FileWriter(path)) {
            for (String[] row : rows) {
                fw.write(String.join(",", row));
                fw.write("\n");
            }
        } catch (Exception e) {
            throw new RuntimeException("CSV export failed", e);
        }
    }
}
