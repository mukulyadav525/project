package edu.univ.erp.api.maintenance;

import edu.univ.erp.service.MaintenanceService;

public class MaintenanceApi {

    private final MaintenanceService maintenanceService = new MaintenanceService();

    public boolean isMaintenanceOn() {
        return maintenanceService.isMaintenanceOn();
    }

    public void setMaintenanceMode(boolean on) {
        maintenanceService.setMaintenanceOn(on);
    }
}
