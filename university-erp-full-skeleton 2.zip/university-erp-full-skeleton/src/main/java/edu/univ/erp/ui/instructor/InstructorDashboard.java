package edu.univ.erp.ui.instructor;

import edu.univ.erp.ui.common.BaseFrame;

import javax.swing.*;

/**
 * Instructor dashboard providing access to teaching-related tools.
 */
public class InstructorDashboard extends BaseFrame {

    public InstructorDashboard() {
        super("Instructor Dashboard");

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("My Sections", new InstructorSectionsPanel());
        tabs.addTab("Grade Entry", new InstructorGradeEntryPanel());
        tabs.addTab("Statistics", new InstructorStatsPanel());

        setContentPane(tabs);
    }
}
