package edu.univ.erp.ui.student;

import edu.univ.erp.ui.common.BaseFrame;

import javax.swing.*;

/**
 * Main dashboard for students.
 * Provides access to catalog browsing, course registration, timetable, and grades.
 */
public class StudentDashboard extends BaseFrame {

    public StudentDashboard() {
        super("Student Dashboard");
        initUi();
    }

    private void initUi() {
        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("📚 Catalog", new StudentCatalogPanel());
        tabs.addTab("📝 My Registrations", new StudentRegistrationsPanel());
        tabs.addTab("🕒 Timetable", new StudentTimetablePanel());
        tabs.addTab("🎓 Grades", new StudentGradesPanel());

        setContentPane(tabs);
    }
}
