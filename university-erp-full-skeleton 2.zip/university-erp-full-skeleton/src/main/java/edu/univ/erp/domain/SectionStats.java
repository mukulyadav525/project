package edu.univ.erp.domain;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Aggregated statistics for a section's final grades.
 */
public class SectionStats {

    private double average;
    private double min;
    private double max;
    private int studentCount;
    private int passCount;
    private int failCount;
    private Map<String, Integer> gradeBuckets = new LinkedHashMap<>();

    public double getAverage() { return average; }
    public void setAverage(double average) { this.average = average; }

    public double getMin() { return min; }
    public void setMin(double min) { this.min = min; }

    public double getMax() { return max; }
    public void setMax(double max) { this.max = max; }

    public int getStudentCount() { return studentCount; }
    public void setStudentCount(int studentCount) { this.studentCount = studentCount; }

    public int getPassCount() { return passCount; }
    public void setPassCount(int passCount) { this.passCount = passCount; }

    public int getFailCount() { return failCount; }
    public void setFailCount(int failCount) { this.failCount = failCount; }

    public Map<String, Integer> getGradeBuckets() { return gradeBuckets; }
    public void setGradeBuckets(Map<String, Integer> gradeBuckets) {
        this.gradeBuckets = (gradeBuckets != null)
                ? new LinkedHashMap<>(gradeBuckets)
                : new LinkedHashMap<>();
    }
}
