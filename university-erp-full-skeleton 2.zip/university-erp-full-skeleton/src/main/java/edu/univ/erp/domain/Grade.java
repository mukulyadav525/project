package edu.univ.erp.domain;

public class Grade {

    private long gradeId;
    private long enrollmentId;
    private String component;
    private double score;
    private Double finalGrade;

    public Grade() {
    }

    public Grade(long gradeId, long enrollmentId, String component, double score, Double finalGrade) {
        this.gradeId = gradeId;
        this.enrollmentId = enrollmentId;
        this.component = component;
        this.score = score;
        this.finalGrade = finalGrade;
    }

    public long getGradeId() {
        return gradeId;
    }

    public void setGradeId(long gradeId) {
        this.gradeId = gradeId;
    }

    public long getEnrollmentId() {
        return enrollmentId;
    }

    public void setEnrollmentId(long enrollmentId) {
        this.enrollmentId = enrollmentId;
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        if (score < 0) {
            throw new IllegalArgumentException("Score cannot be negative.");
        }
        this.score = score;
    }

    public Double getFinalGrade() {
        return finalGrade;
    }

    public void setFinalGrade(Double finalGrade) {
        this.finalGrade = finalGrade;
    }

    @Override
    public String toString() {
        return "Grade{" +
                "gradeId=" + gradeId +
                ", enrollmentId=" + enrollmentId +
                ", component='" + component + '\'' +
                ", score=" + score +
                ", finalGrade=" + finalGrade +
                '}';
    }
}
