package edu.univ.erp.data;

import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.util.DbConnectionPool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentRepository {

    public boolean exists(long studentId, long sectionId) {
        if (studentId <= 0 || sectionId <= 0) {
            return false;
        }

        final String sql = "SELECT 1 FROM enrollments WHERE student_id = ? AND section_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, studentId);
            ps.setLong(2, sectionId);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to check enrollment existence", e);
        }
    }

    public int countBySection(long sectionId) {
        if (sectionId <= 0) {
            return 0;
        }

        final String sql =
                "SELECT COUNT(*) FROM enrollments WHERE section_id = ? AND status = 'ENROLLED'";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, sectionId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to count enrollments for section: " + sectionId, e);
        }

        return 0;
    }

    public boolean insert(long studentId, long sectionId) {
        if (studentId <= 0 || sectionId <= 0) {
            throw new IllegalArgumentException("Student ID and Section ID must be positive.");
        }

        final String sql =
                "INSERT INTO enrollments (student_id, section_id, status) VALUES (?, ?, 'ENROLLED')";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, studentId);
            ps.setLong(2, sectionId);

            return ps.executeUpdate() == 1;

        } catch (Exception e) {
            throw new RuntimeException("Failed to insert enrollment", e);
        }
    }

    public boolean delete(long studentId, long sectionId) {
        if (studentId <= 0 || sectionId <= 0) {
            throw new IllegalArgumentException("Student ID and Section ID must be positive.");
        }

        final String sql =
                "DELETE FROM enrollments WHERE student_id = ? AND section_id = ?";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, studentId);
            ps.setLong(2, sectionId);

            return ps.executeUpdate() == 1;

        } catch (Exception e) {
            throw new RuntimeException("Failed to delete enrollment", e);
        }
    }

    public List<Enrollment> findByStudent(long studentId) {
        List<Enrollment> list = new ArrayList<>();
        if (studentId <= 0) {
            return list;
        }

        final String sql =
                "SELECT enrollment_id, student_id, section_id, status " +
                        "FROM enrollments WHERE student_id = ? AND status = 'ENROLLED'";

        try (Connection conn = DbConnectionPool.erpDataSource().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, studentId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Enrollment e = new Enrollment();
                    e.setEnrollmentId(rs.getLong("enrollment_id"));
                    e.setStudentId(rs.getLong("student_id"));
                    e.setSectionId(rs.getLong("section_id"));
                    e.setStatus(rs.getString("status"));
                    list.add(e);
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch enrollments for student: " + studentId, e);
        }

        return list;
    }
}
