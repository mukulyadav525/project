package edu.univ.erp.service;

import edu.univ.erp.auth.AuthRepository;
import edu.univ.erp.auth.AuthService;
import edu.univ.erp.data.CourseRepository;
import edu.univ.erp.data.InstructorRepository;
import edu.univ.erp.data.SectionRepository;
import edu.univ.erp.data.SettingsRepository;
import edu.univ.erp.data.StudentRepository;
import edu.univ.erp.domain.Course;
import edu.univ.erp.domain.Section;

import java.time.LocalDateTime;
import java.util.List;

/**
 * AdminService
 *
 * Orchestrates admin operations:
 * - Maintenance mode & banner
 * - Registration & drop deadlines
 * - Course & Section management
 * - Instructor assignment
 *
 * NOTE: Some repository method names are assumed; adjust if your actual names differ.
 */
public class AdminService {

    // Maintenance & settings
    private final MaintenanceService maintenanceService = new MaintenanceService();
    private final SettingsRepository settingsRepository = new SettingsRepository();

    // User-related (ready for future features)
    private final AuthService authService = new AuthService();
    private final AuthRepository authRepository = new AuthRepository();
    private final StudentRepository studentRepository = new StudentRepository();
    private final InstructorRepository instructorRepository = new InstructorRepository();

    // Catalog data
    private final CourseRepository courseRepository = new CourseRepository();
    private final SectionRepository sectionRepository = new SectionRepository();

    // =====================================================================
    // Maintenance Mode
    // =====================================================================

    /**
     * Canonical method used by AdminApi.setMaintenanceMode().
     *
     * @param on            whether maintenance is enabled.
     * @param bannerMessage message to display in UI when maintenance is ON.
     *
     * Expected MaintenanceService:
     *  - void setMaintenanceOn(boolean on)
     *  - void setMaintenanceBanner(String banner)
     */
    public void setMaintenanceMode(boolean on, String bannerMessage) {
        maintenanceService.setMaintenanceOn(on);
        // If your MaintenanceService doesn't yet support banners,
        // add setMaintenanceBanner/getMaintenanceBanner there.
        maintenanceService.setMaintenanceBanner(bannerMessage);
    }

    /**
     * Backwards-compatible simple toggle.
     * Uses a default banner text when turning ON.
     */
    public void toggleMaintenance(boolean on) {
        String defaultBanner = on ? "The system is currently under maintenance." : "";
        setMaintenanceMode(on, defaultBanner);
    }

    /**
     * @return true if maintenance mode is currently enabled.
     *
     * Expected MaintenanceService:
     *  - boolean isMaintenanceOn()
     */
    public boolean isMaintenanceOn() {
        return maintenanceService.isMaintenanceOn();
    }

    /**
     * @return current maintenance banner text (may be empty if not set).
     *
     * Expected MaintenanceService:
     *  - String getMaintenanceBanner()
     */
    public String getMaintenanceBanner() {
        return maintenanceService.getMaintenanceBanner();
    }

    // =====================================================================
    // Registration & Drop Deadlines
    // =====================================================================
    //
    // AdminApi uses these. StudentApi/Student UIs read from SettingsRepository.
    // SettingsRepository:
    //  - LocalDateTime getRegistrationDeadline()
    //  - void setRegistrationDeadline(LocalDateTime)
    //  - LocalDateTime getDropDeadline()
    //  - void setDropDeadline(LocalDateTime)
    // =====================================================================

    public void setRegistrationDeadline(LocalDateTime deadline) {
        settingsRepository.setRegistrationDeadline(deadline);
    }

    public LocalDateTime getRegistrationDeadline() {
        return settingsRepository.getRegistrationDeadline();
    }

    public void setDropDeadline(LocalDateTime deadline) {
        settingsRepository.setDropDeadline(deadline);
    }

    public LocalDateTime getDropDeadline() {
        return settingsRepository.getDropDeadline();
    }

    // =====================================================================
    // Courses
    // =====================================================================

    /**
     * Create a new course.
     */
    public void createCourse(Course course) {
        if (course == null) {
            throw new IllegalArgumentException("Course must not be null.");
        }
        if (isEmpty(course.getCode()) || isEmpty(course.getTitle())) {
            throw new IllegalArgumentException("Course code and title are required.");
        }
        courseRepository.insert(course);
    }

    /**
     * Update an existing course.
     *
     * Expected CourseRepository:
     *  - void update(Course c)
     */
    public void updateCourse(Course course) {
        if (course == null || isEmpty(course.getCode())) {
            throw new IllegalArgumentException("Course and course code are required.");
        }
        courseRepository.update(course);
    }

    /**
     * Delete a course by its code.
     *
     * Expected CourseRepository:
     *  - void deleteByCode(String code)
     */
    public void deleteCourse(String code) {
        if (isEmpty(code)) {
            throw new IllegalArgumentException("Course code is required.");
        }
        courseRepository.deleteByCode(code);
    }

    /**
     * List all courses.
     *
     * Expected CourseRepository:
     *  - List<Course> getAllCourses()
     */
    public List<Course> getAllCourses() {
        return courseRepository.getAllCourses();
    }

    // =====================================================================
    // Sections
    // =====================================================================

    /**
     * Create a new section.
     */
    public void createSection(Section section) {
        if (section == null) {
            throw new IllegalArgumentException("Section must not be null.");
        }
        sectionRepository.insert(section);
    }

    /**
     * Update an existing section.
     *
     * Expected SectionRepository:
     *  - void update(Section s)
     */
    public void updateSection(Section section) {
        if (section == null || section.getId() == null) {
            throw new IllegalArgumentException("Section and section ID are required.");
        }
        sectionRepository.update(section);
    }

    /**
     * Delete section by ID.
     *
     * Expected SectionRepository:
     *  - void delete(long id)
     */
    public void deleteSection(long sectionId) {
        sectionRepository.delete(sectionId);
    }

    /**
     * List all sections.
     *
     * Expected SectionRepository:
     *  - List<Section> getAllSections()
     */
    public List<Section> getAllSections() {
        return sectionRepository.getAllSections();
    }

    /**
     * List sections for a specific course.
     *
     * Expected SectionRepository:
     *  - List<Section> getSectionsByCourse(String courseCode)
     */
    public List<Section> getSectionsByCourse(String courseCode) {
        if (isEmpty(courseCode)) {
            throw new IllegalArgumentException("Course code is required.");
        }
        return sectionRepository.getSectionsByCourse(courseCode);
    }

    // =====================================================================
    // Instructor Assignment
    // =====================================================================

    /**
     * Assign an instructor to a section.
     *
     * Expected SectionRepository:
     *  - void assignInstructor(long sectionId, long instructorId)
     */
    public void assignInstructor(long sectionId, long instructorId) {
        if (sectionId <= 0 || instructorId <= 0) {
            throw new IllegalArgumentException("Section ID and Instructor ID must be positive.");
        }
        sectionRepository.assignInstructor(sectionId, instructorId);
    }

    // =====================================================================
    // Helpers
    // =====================================================================

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }
}
