package edu.univ.erp.ui.admin;

import edu.univ.erp.api.admin.AdminApi;
import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.domain.Section;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminSectionsPanel extends JPanel {

    private final AdminApi adminApi = new AdminApi();

    private final JTextField courseCodeField;
    private final JTextField dayTimeField;
    private final JTextField roomField;
    private final JTextField capacityField;
    private final JTextField semesterField;
    private final JTextField yearField;

    private final JButton createButton;
    private final JButton updateButton;
    private final JButton deleteButton;
    private final JButton clearButton;

    private final JTable sectionsTable;
    private final DefaultTableModel tableModel;

    private Long selectedSectionId = null;

    public AdminSectionsPanel() {
        setLayout(new BorderLayout(8, 8));

        // ===== Form =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        courseCodeField = new JTextField(12);
        dayTimeField = new JTextField(20);   // e.g., "Mon/Wed 10:00-11:30"
        roomField = new JTextField(10);
        capacityField = new JTextField(6);
        semesterField = new JTextField(8);  // e.g., "Fall", "Spring"
        yearField = new JTextField(6);      // e.g., "2025"

        int row = 0;

        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Course Code:"), gbc);
        gbc.gridx = 1;
        formPanel.add(courseCodeField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Day/Time:"), gbc);
        gbc.gridx = 1;
        formPanel.add(dayTimeField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Room:"), gbc);
        gbc.gridx = 1;
        formPanel.add(roomField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx = 1;
        formPanel.add(capacityField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Semester:"), gbc);
        gbc.gridx = 1;
        formPanel.add(semesterField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        formPanel.add(new JLabel("Year:"), gbc);
        gbc.gridx = 1;
        formPanel.add(yearField, gbc);

        // ===== Buttons =====
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        createButton = new JButton("Create");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear");

        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);

        buttonPanel.add(createButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);

        add(formPanel, BorderLayout.NORTH);

        // ===== Table =====
        tableModel = new DefaultTableModel(
                new Object[]{"ID", "Course Code", "Day/Time", "Room", "Capacity", "Semester", "Year"}, 0
        ) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };

        sectionsTable = new JTable(tableModel);
        sectionsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sectionsTable.setRowHeight(22);
        sectionsTable.getColumnModel().getColumn(0).setPreferredWidth(40); // ID

        add(new JScrollPane(sectionsTable), BorderLayout.CENTER);

        // ===== Listeners =====
        createButton.addActionListener(e -> onCreate());
        updateButton.addActionListener(e -> onUpdate());
        deleteButton.addActionListener(e -> onDelete());
        clearButton.addActionListener(e -> clearForm());

        sectionsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                onTableSelectionChanged();
            }
        });

        // Initial load
        loadSections();
    }

    private void onCreate() {
        Section section = buildSectionFromForm(false);
        if (section == null) return;

        ApiResponse<Void> resp = adminApi.createSection(section);

        if (resp.isSuccess()) {
            JOptionPane.showMessageDialog(this,
                    "Section created successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            loadSections();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this,
                    resp.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onUpdate() {
        if (selectedSectionId == null) {
            return;
        }

        Section section = buildSectionFromForm(true);
        if (section == null) return;

        section.setId(selectedSectionId);

        ApiResponse<Void> resp = adminApi.updateSection(section);

        if (resp.isSuccess()) {
            JOptionPane.showMessageDialog(this,
                    "Section updated successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            loadSections();
            reselectById(selectedSectionId);
        } else {
            JOptionPane.showMessageDialog(this,
                    resp.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onDelete() {
        if (selectedSectionId == null) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this section?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        ApiResponse<Void> resp = adminApi.deleteSection(selectedSectionId);

        if (resp.isSuccess()) {
            JOptionPane.showMessageDialog(this,
                    "Section deleted successfully.",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            loadSections();
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this,
                    resp.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onTableSelectionChanged() {
        int row = sectionsTable.getSelectedRow();
        if (row == -1) {
            selectedSectionId = null;
            updateButton.setEnabled(false);
            deleteButton.setEnabled(false);
            return;
        }

        selectedSectionId = (Long) tableModel.getValueAt(row, 0);
        String courseCode = (String) tableModel.getValueAt(row, 1);
        String dayTime = (String) tableModel.getValueAt(row, 2);
        String room = (String) tableModel.getValueAt(row, 3);
        Integer capacity = (Integer) tableModel.getValueAt(row, 4);
        String semester = (String) tableModel.getValueAt(row, 5);
        Integer year = (Integer) tableModel.getValueAt(row, 6);

        courseCodeField.setText(courseCode);
        dayTimeField.setText(dayTime);
        roomField.setText(room);
        capacityField.setText(capacity != null ? capacity.toString() : "");
        semesterField.setText(semester);
        yearField.setText(year != null ? year.toString() : "");

        updateButton.setEnabled(true);
        deleteButton.setEnabled(true);
    }

    private void clearForm() {
        selectedSectionId = null;
        courseCodeField.setText("");
        dayTimeField.setText("");
        roomField.setText("");
        capacityField.setText("");
        semesterField.setText("");
        yearField.setText("");
        sectionsTable.clearSelection();
        updateButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    private Section buildSectionFromForm(boolean forUpdate) {
        String courseCode = courseCodeField.getText().trim();
        String dayTime = dayTimeField.getText().trim();
        String room = roomField.getText().trim();
        String capacityText = capacityField.getText().trim();
        String semester = semesterField.getText().trim();
        String yearText = yearField.getText().trim();

        if (courseCode.isEmpty() || dayTime.isEmpty() || room.isEmpty()
                || capacityText.isEmpty() || semester.isEmpty() || yearText.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "All fields are required.",
                    "Input Error",
                    JOptionPane.WARNING_MESSAGE
            );
            return null;
        }

        int capacity;
        int year;
        try {
            capacity = Integer.parseInt(capacityText);
            year = Integer.parseInt(yearText);

            if (capacity < 0) {
                throw new NumberFormatException("Negative capacity not allowed.");
            }
            if (year < 0) {
                throw new NumberFormatException("Negative year not allowed.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Capacity and Year must be valid non-negative integers.",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return null;
        }

        Section section = new Section();
        section.setCourseCode(courseCode);
        section.setDayTime(dayTime);
        section.setRoom(room);
        section.setCapacity(capacity);
        section.setSemester(semester);
        section.setYear(year);

        if (forUpdate && selectedSectionId != null) {
            section.setId(selectedSectionId);
        }

        return section;
    }

    private void loadSections() {
        tableModel.setRowCount(0);

        ApiResponse<List<Section>> resp = adminApi.getAllSections();
        if (!resp.isSuccess()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to load sections: " + resp.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        List<Section> sections = resp.getData();
        if (sections == null) return;

        for (Section s : sections) {
            tableModel.addRow(new Object[]{
                    s.getId(),
                    s.getCourseCode(),
                    s.getDayTime(),
                    s.getRoom(),
                    s.getCapacity(),
                    s.getSemester(),
                    s.getYear()
            });
        }
    }

    private void reselectById(Long id) {
        if (id == null) return;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Object value = tableModel.getValueAt(i, 0);
            if (value instanceof Long && ((Long) value).equals(id)) {
                sectionsTable.setRowSelectionInterval(i, i);
                break;
            }
        }
    }
}
