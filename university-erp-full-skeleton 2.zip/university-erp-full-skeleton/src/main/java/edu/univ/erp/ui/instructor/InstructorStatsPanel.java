package edu.univ.erp.ui.instructor;

import edu.univ.erp.api.common.ApiResponse;
import edu.univ.erp.api.instructor.InstructorApi;
import edu.univ.erp.domain.Section;
import edu.univ.erp.domain.SectionStats;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Map;

/**
 * Shows simple statistics for the instructor's sections:
 * - Class average, min, max
 * - Enrolled / pass / fail counts
 * - Simple grade distribution
 */
public class InstructorStatsPanel extends JPanel {

    private final InstructorApi instructorApi = new InstructorApi();

    private final JComboBox<Section> sectionCombo;
    private final JLabel summaryLabel;
    private final JLabel avgLabel;
    private final JLabel minLabel;
    private final JLabel maxLabel;
    private final JLabel countLabel;
    private final JLabel passLabel;
    private final JLabel failLabel;
    private final DefaultTableModel distributionModel;

    public InstructorStatsPanel() {
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        JLabel title = new JLabel("Class Statistics");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 16f));
        header.add(title, BorderLayout.NORTH);

        JLabel hint = new JLabel(
                "<html><i>Select one of your sections to see its basic statistics.</i></html>"
        );
        hint.setFont(hint.getFont().deriveFont(Font.PLAIN, 11f));
        header.add(hint, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);

        // Top controls: section selector + refresh
        JPanel topControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        topControls.add(new JLabel("Section:"));

        sectionCombo = new JComboBox<>();
        sectionCombo.addActionListener(e -> loadStatsForSelectedSection());
        topControls.add(sectionCombo);

        JButton refreshButton = new JButton("Refresh Sections");
        refreshButton.addActionListener(e -> loadSections());
        topControls.add(refreshButton);

        summaryLabel = new JLabel(" ");
        summaryLabel.setFont(summaryLabel.getFont().deriveFont(Font.PLAIN, 11f));

        JPanel topWrapper = new JPanel(new BorderLayout());
        topWrapper.add(topControls, BorderLayout.WEST);
        topWrapper.add(summaryLabel, BorderLayout.SOUTH);

        add(topWrapper, BorderLayout.BEFORE_FIRST_LINE);

        // Center: stats + distribution
        JPanel center = new JPanel(new BorderLayout(8, 8));

        // Numeric stats panel
        JPanel statsPanel = new JPanel(new GridLayout(0, 2, 6, 4));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Summary"));

        avgLabel = new JLabel("-");
        minLabel = new JLabel("-");
        maxLabel = new JLabel("-");
        countLabel = new JLabel("-");
        passLabel = new JLabel("-");
        failLabel = new JLabel("-");

        statsPanel.add(new JLabel("Class Average:"));
        statsPanel.add(avgLabel);

        statsPanel.add(new JLabel("Minimum Final:"));
        statsPanel.add(minLabel);

        statsPanel.add(new JLabel("Maximum Final:"));
        statsPanel.add(maxLabel);

        statsPanel.add(new JLabel("Enrolled Students:"));
        statsPanel.add(countLabel);

        statsPanel.add(new JLabel("Pass Count:"));
        statsPanel.add(passLabel);

        statsPanel.add(new JLabel("Fail Count:"));
        statsPanel.add(failLabel);

        center.add(statsPanel, BorderLayout.NORTH);

        // Grade distribution table
        distributionModel = new DefaultTableModel(
                new Object[]{"Grade Range / Bucket", "Count"},
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable distributionTable = new JTable(distributionModel);
        distributionTable.setFillsViewportHeight(true);

        JScrollPane distributionScroll = new JScrollPane(distributionTable);
        distributionScroll.setBorder(
                BorderFactory.createTitledBorder("Grade Distribution")
        );

        center.add(distributionScroll, BorderLayout.CENTER);

        add(center, BorderLayout.CENTER);

        // Initial load
        loadSections();
    }

    private void loadSections() {
        sectionCombo.removeAllItems();
        summaryLabel.setText("Loading sections...");

        ApiResponse<List<Section>> resp = instructorApi.mySections();

        if (!resp.isSuccess()) {
            summaryLabel.setText(" ");
            if (resp.getMessage() != null && !resp.getMessage().isBlank()) {
                JOptionPane.showMessageDialog(
                        this,
                        resp.getMessage(),
                        "Error Loading Sections",
                        JOptionPane.ERROR_MESSAGE
                );
            }
            clearStats();
            return;
        }

        List<Section> sections = resp.getData();
        if (sections == null || sections.isEmpty()) {
            summaryLabel.setText("No sections assigned to you.");
            clearStats();
            return;
        }

        for (Section s : sections) {
            sectionCombo.addItem(s);
        }

        summaryLabel.setText(sections.size() + " section(s) available.");
        if (sectionCombo.getItemCount() > 0) {
            sectionCombo.setSelectedIndex(0);
            loadStatsForSelectedSection();
        }
    }

    private void loadStatsForSelectedSection() {
        Object sel = sectionCombo.getSelectedItem();
        if (!(sel instanceof Section)) {
            clearStats();
            return;
        }

        Section section = (Section) sel;

        // If getSectionId() is primitive long, treat <=0 as invalid.
        long id = section.getSectionId();
        if (id <= 0) {
            clearStats();
            return;
        }
        long sectionId = id;

        clearStats();
        summaryLabel.setText("Loading stats for section " + sectionId + "...");

        ApiResponse<SectionStats> resp = instructorApi.sectionStats(sectionId);

        if (!resp.isSuccess()) {
            summaryLabel.setText(" ");
            if (resp.getMessage() != null && !resp.getMessage().isBlank()) {
                JOptionPane.showMessageDialog(
                        this,
                        resp.getMessage(),
                        "Error Loading Statistics",
                        JOptionPane.ERROR_MESSAGE
                );
            }
            return;
        }

        SectionStats stats = resp.getData();
        if (stats == null) {
            summaryLabel.setText("No statistics available for this section.");
            return;
        }

        avgLabel.setText(formatDouble(stats.getAverage()));
        minLabel.setText(formatDouble(stats.getMin()));
        maxLabel.setText(formatDouble(stats.getMax()));
        countLabel.setText(String.valueOf(stats.getStudentCount()));
        passLabel.setText(String.valueOf(stats.getPassCount()));
        failLabel.setText(String.valueOf(stats.getFailCount()));

        distributionModel.setRowCount(0);
        Map<String, Integer> buckets = stats.getGradeBuckets();
        if (buckets != null && !buckets.isEmpty()) {
            for (Map.Entry<String, Integer> e : buckets.entrySet()) {
                distributionModel.addRow(new Object[]{e.getKey(), e.getValue()});
            }
        }

        summaryLabel.setText("Statistics loaded for section " + sectionId + ".");
    }

    private void clearStats() {
        avgLabel.setText("-");
        minLabel.setText("-");
        maxLabel.setText("-");
        countLabel.setText("-");
        passLabel.setText("-");
        failLabel.setText("-");
        distributionModel.setRowCount(0);
    }

    private String formatDouble(double v) {
        if (Double.isNaN(v)) return "-";
        return String.format("%.2f", v);
    }
}
