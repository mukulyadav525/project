package edu.univ.erp.util;

import java.io.InputStream;
import java.util.Properties;

public class DbConfig {

    private static final Properties props = new Properties();

    static {
        try (InputStream in = DbConfig.class
                .getClassLoader()
                .getResourceAsStream("db.properties")) { // ✅ must match src/main/resources/db.properties
            if (in == null) {
                throw new RuntimeException("db.properties not found on classpath");
            }
            props.load(in);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load db.properties", e);
        }
    }

    public static String get(String key) {
        String value = props.getProperty(key);
        if (value == null) {
            throw new RuntimeException("Missing DB config key: " + key);
        }
        return value;
    }
}
