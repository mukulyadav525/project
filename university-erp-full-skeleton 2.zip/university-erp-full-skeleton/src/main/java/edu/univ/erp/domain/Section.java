package edu.univ.erp.domain;

/**
 * Represents an academic section (course offering) with instructor and schedule information.
 */
public class Section {

    private long sectionId;
    private String courseCode;
    private Long instructorId;
    private String instructorName; // newly used for mapped instructor display
    private String dayTime;
    private String room;
    private int capacity;
    private String semester;
    private int year;

    public Section() {
        // Default constructor
    }

    public Section(long sectionId, String courseCode, Long instructorId, String instructorName,
                   String dayTime, String room, int capacity, String semester, int year) {
        this.sectionId = sectionId;
        this.courseCode = courseCode;
        this.instructorId = instructorId;
        this.instructorName = instructorName;
        this.dayTime = dayTime;
        this.room = room;
        this.capacity = capacity;
        this.semester = semester;
        this.year = year;
    }

    // ---- Getters and Setters ---- //

    public long getSectionId() {
        return sectionId;
    }

    public void setSectionId(long sectionId) {
        this.sectionId = sectionId;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public Long getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(Long instructorId) {
        this.instructorId = instructorId;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    public String getDayTime() {
        return dayTime;
    }

    public void setDayTime(String dayTime) {
        this.dayTime = dayTime;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        if (capacity < 0) {
            throw new IllegalArgumentException("Capacity cannot be negative.");
        }
        this.capacity = capacity;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (year < 0) {
            throw new IllegalArgumentException("Year cannot be negative.");
        }
        this.year = year;
    }

    @Override
    public String toString() {
        return "Section{" +
                "sectionId=" + sectionId +
                ", courseCode='" + courseCode + '\'' +
                ", instructorId=" + instructorId +
                ", instructorName='" + instructorName + '\'' +
                ", dayTime='" + dayTime + '\'' +
                ", room='" + room + '\'' +
                ", capacity=" + capacity +
                ", semester='" + semester + '\'' +
                ", year=" + year +
                '}';
    }
}
