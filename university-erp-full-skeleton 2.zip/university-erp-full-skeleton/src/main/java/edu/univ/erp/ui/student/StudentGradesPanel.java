package edu.univ.erp.ui.student;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Displays detailed grades for the logged-in student.
 *
 * Components:
 *  - Quiz
 *  - Project
 *  - Assignments
 *  - Mid Sem
 *  - End Sem
 *
 * Total = sum of components (adjust if your weighting is different).
 */
public class StudentGradesPanel extends JPanel {

    private JTable gradesTable;
    private GradesTableModel tableModel;

    public StudentGradesPanel() {
        setLayout(new BorderLayout());

        // Header
        JLabel header = new JLabel("My Course Grades", SwingConstants.LEFT);
        header.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        header.setFont(header.getFont().deriveFont(Font.BOLD, 16f));
        add(header, BorderLayout.NORTH);

        // Table + model
        tableModel = new GradesTableModel(fetchGradesForCurrentStudent());
        gradesTable = new JTable(tableModel);
        gradesTable.setFillsViewportHeight(true);
        gradesTable.setRowHeight(24);
        gradesTable.getTableHeader().setReorderingAllowed(false);
        gradesTable.setAutoCreateRowSorter(true); // allow sorting

        add(new JScrollPane(gradesTable), BorderLayout.CENTER);

        // Export button
        JButton exportButton = new JButton("Export as CSV");
        exportButton.addActionListener(e -> exportToCsv());

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(4, 8, 8, 8));
        bottomPanel.add(exportButton);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    /**
     * TODO: Replace this with real data from your StudentApi / GradeRepository
     * using the logged-in student's ID from SessionContext.
     */
    private List<StudentCourseGrade> fetchGradesForCurrentStudent() {
        List<StudentCourseGrade> list = new ArrayList<>();

        // SAMPLE DATA (for demo). Remove once wired to backend.
        list.add(new StudentCourseGrade("CS101", "Intro to Programming",
                8, 18, 12, 25, 30));
        list.add(new StudentCourseGrade("MA102", "Calculus II",
                7, 15, 10, 23, 28));
        list.add(new StudentCourseGrade("EN201", "Technical Writing",
                9, 17, 13, 24, 29));

        return list;
    }

    /**
     * Export current table contents as CSV.
     */
    private void exportToCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save Grades as CSV");

        int result = chooser.showSaveDialog(this);
        if (result != JFileChooser.APPROVE_OPTION) {
            return; // user cancelled
        }

        File file = chooser.getSelectedFile();
        // Ensure .csv extension
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new File(file.getParentFile(), file.getName() + ".csv");
        }

        try (PrintWriter out = new PrintWriter(new FileWriter(file))) {
            // Header row
            for (int c = 0; c < tableModel.getColumnCount(); c++) {
                if (c > 0) out.print(",");
                out.print(escapeCsv(tableModel.getColumnName(c)));
            }
            out.println();

            // Data rows
            for (int r = 0; r < tableModel.getRowCount(); r++) {
                for (int c = 0; c < tableModel.getColumnCount(); c++) {
                    if (c > 0) out.print(",");
                    Object value = tableModel.getValueAt(r, c);
                    out.print(escapeCsv(value == null ? "" : value.toString()));
                }
                out.println();
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Grades exported to:\n" + file.getAbsolutePath(),
                    "Export Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Failed to export CSV:\n" + ex.getMessage(),
                    "Export Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    /**
     * Basic CSV escaping: wrap in quotes if needed and escape interior quotes.
     */
    private String escapeCsv(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            s = s.replace("\"", "\"\"");
            return "\"" + s + "\"";
        }
        return s;
    }

    /**
     * Represents grades for a single course.
     */
    private static class StudentCourseGrade {
        String courseCode;
        String courseTitle;
        double quiz;
        double project;
        double assignments;
        double midSem;
        double endSem;

        StudentCourseGrade(String courseCode, String courseTitle,
                           double quiz, double project, double assignments,
                           double midSem, double endSem) {
            this.courseCode = courseCode;
            this.courseTitle = courseTitle;
            this.quiz = quiz;
            this.project = project;
            this.assignments = assignments;
            this.midSem = midSem;
            this.endSem = endSem;
        }

        double getTotal() {
            return quiz + project + assignments + midSem + endSem;
        }

        String getLetterGrade() {
            double t = getTotal();
            if (t >= 90) return "A+";
            if (t >= 80) return "A";
            if (t >= 70) return "B";
            if (t >= 60) return "C";
            if (t >= 50) return "D";
            return "F";
        }
    }

    /**
     * Table model backing the grades table.
     */
    private static class GradesTableModel extends AbstractTableModel {

        private final String[] columns = {
                "Course Code",
                "Course Title",
                "Quiz",
                "Project",
                "Assignments",
                "Mid Sem",
                "End Sem",
                "Total",
                "Grade"
        };

        private final List<StudentCourseGrade> data;

        GradesTableModel(List<StudentCourseGrade> data) {
            this.data = data;
        }

        @Override
        public int getRowCount() {
            return data.size();
        }

        @Override
        public int getColumnCount() {
            return columns.length;
        }

        @Override
        public String getColumnName(int column) {
            return columns[column];
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            StudentCourseGrade g = data.get(rowIndex);
            return switch (columnIndex) {
                case 0 -> g.courseCode;
                case 1 -> g.courseTitle;
                case 2 -> g.quiz;
                case 3 -> g.project;
                case 4 -> g.assignments;
                case 5 -> g.midSem;
                case 6 -> g.endSem;
                case 7 -> g.getTotal();
                case 8 -> g.getLetterGrade();
                default -> "";
            };
        }

        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return switch (columnIndex) {
                case 2, 3, 4, 5, 6, 7 -> Double.class;
                default -> String.class;
            };
        }

        @Override
        public boolean isCellEditable(int rowIndex, int columnIndex) {
            return false; // view-only for students
        }
    }
}
