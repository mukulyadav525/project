package edu.univ.erp.service;

import edu.univ.erp.data.EnrollmentRepository;
import edu.univ.erp.data.GradeRepository;
import edu.univ.erp.domain.Enrollment;
import edu.univ.erp.domain.Grade;

import java.util.List;

public class ReportService {

    private final EnrollmentRepository enrollmentRepository = new EnrollmentRepository();
    private final GradeRepository gradeRepository = new GradeRepository();

    /**
     * Get the class list (enrollments) for a given section.
     * Currently not implemented because EnrollmentRepository
     * only supports lookups by student. Extend it later if needed.
     */
    public List<Enrollment> getClassList(long sectionId) {
        if (sectionId <= 0) {
            throw new IllegalArgumentException("Section ID must be positive.");
        }
        throw new UnsupportedOperationException(
                "getClassList is not yet implemented. Add findBySection() in EnrollmentRepository."
        );
    }

    /**
     * Get all grade records for a given enrollment.
     * Useful for transcript or report generation.
     */
    public List<Grade> getGradesForEnrollment(long enrollmentId) {
        if (enrollmentId <= 0) {
            throw new IllegalArgumentException("Enrollment ID must be positive.");
        }
        return gradeRepository.findByEnrollment(enrollmentId);
    }

    /**
     * Placeholder for CSV or PDF export integration.
     * Implement this once CsvExporter or PdfExporter utilities are available.
     */
    public void exportTranscriptToFile(long enrollmentId, String format) {
        // Example stub: could call CsvExporter.export() or PdfExporter.export()
        throw new UnsupportedOperationException("Export functionality not yet implemented.");
    }
}
