package edu.univ.erp.auth;

import edu.univ.erp.domain.UserAccount;

/**
 * Simple session holder using ThreadLocal.
 * Replace with real HTTP/session integration in your framework.
 */
public final class SessionContext {

    private static final ThreadLocal<UserAccount> CURRENT_USER = new ThreadLocal<>();

    private SessionContext() {
        // Prevent instantiation
    }

    public static void setCurrentUser(UserAccount user) {
        CURRENT_USER.set(user);
    }

    public static UserAccount getCurrentUser() {
        return CURRENT_USER.get();
    }

    public static boolean isLoggedIn() {
        return CURRENT_USER.get() != null;
    }

    public static void clear() {
        CURRENT_USER.remove();
    }
}
